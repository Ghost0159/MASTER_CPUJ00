﻿namespace AdminTool
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.textBoxAdminResult = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.設定SToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.接続サーバToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemDebugServer = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemReleaseServer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItemDevDebugServer = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemDevReleaseServer = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemProxySetting = new System.Windows.Forms.ToolStripMenuItem();
            this.ヘルプFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemVersion = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.backgroundWorkerThread = new System.ComponentModel.BackgroundWorker();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.openFileDialogSettingXML = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialogSettingXML = new System.Windows.Forms.SaveFileDialog();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label51 = new System.Windows.Forms.Label();
            this.textBoxVipConfirmVipPid_UserId = new System.Windows.Forms.TextBox();
            this.labelVipConfirmWarning = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBoxVipConfirm4 = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirm3 = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirm2 = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirm1 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBoxVipConfirmD = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmC = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmB = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmA = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxVipConfirmPasswordSP = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmPasswordDE = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmPasswordIT = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmPasswordFR = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmPasswordEN = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmPasswordKR = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmPasswordJP = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxVipConfirmKey = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmEventId = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmVipPid = new System.Windows.Forms.TextBox();
            this.textBoxVipConfirmClientTrainerId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxVipClientTrainerId = new System.Windows.Forms.TextBox();
            this.dataGridViewVipRecord = new System.Windows.Forms.DataGridView();
            this.buttonGetVipExecute = new System.Windows.Forms.Button();
            this.bindingNavigatorVipSettingRecord = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonCopyVipRecords = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLoadVipSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSaveVipSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonAdminGetVipSettingRecordExecute = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAdminSetVipSettingExecute = new System.Windows.Forms.ToolStripButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.listViewUserSchedule = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.buttonGetScheduleExecute = new System.Windows.Forms.Button();
            this.bindingNavigatorSchedule = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem1 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonCopySchedule = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLoadScheduleSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSaveScheduleSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonAdminGetScheduleExecute = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAdminSetScheduleExecute = new System.Windows.Forms.ToolStripButton();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.textBoxQuestionnaireInfo = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.textBoxGetQuestionnaireLanguage = new System.Windows.Forms.TextBox();
            this.buttonGetQuestionnaire = new System.Windows.Forms.Button();
            this.bindingNavigatorSpecialWeek = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonCopySpecialWeekRecord = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLoadSpecialWeekSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSaveSpecialWeek = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonAdminGetSpecialWeekSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAdminSetSpecialWeekSetting = new System.Windows.Forms.ToolStripButton();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.buttonSaveFreeQuestionSetting = new System.Windows.Forms.Button();
            this.buttonLoadFreeQuestionSetting = new System.Windows.Forms.Button();
            this.buttonGetFreeQuestion = new System.Windows.Forms.Button();
            this.buttonSetFreeQuestion = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonQuestionnaireUpdate = new System.Windows.Forms.Button();
            this.buttonInitializeQuestionnaire = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label80 = new System.Windows.Forms.Label();
            this.buttonSetDefaultSummerizeLanguage = new System.Windows.Forms.Button();
            this.label79 = new System.Windows.Forms.Label();
            this.checkedListBoxDefaultSummerizeLanguage = new System.Windows.Forms.CheckedListBox();
            this.label66 = new System.Windows.Forms.Label();
            this.buttonSetSpecialQuestionThreshold = new System.Windows.Forms.Button();
            this.textBoxSetQuestionSerialNo = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBoxSetNextQuestionNo = new System.Windows.Forms.TextBox();
            this.textBoxSetSpecialQuestionThreshold = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBoxSetQuestionNo = new System.Windows.Forms.TextBox();
            this.buttonSetQuestionNo = new System.Windows.Forms.Button();
            this.label77 = new System.Windows.Forms.Label();
            this.buttonSetNextQuestionNo = new System.Windows.Forms.Button();
            this.buttonSetQuestionSerialNo = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label69 = new System.Windows.Forms.Label();
            this.textBoxSubmitQuestionnaireProfileId = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBoxSubmitQuestionnaireAnswerNo = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBoxSubmitQuestionnaireLanguage = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.textBoxSubmitQuestionnaireSerialNo = new System.Windows.Forms.TextBox();
            this.buttonSubmitQuestionnaire = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.textBoxCheckProfileTrainerTypeResult = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileTrainerType = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.buttonCheckProfile = new System.Windows.Forms.Button();
            this.label59 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileRomCodeResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileRegionResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileCountryResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileLanguageResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileSexResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileNameResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileTrainerIdResult = new System.Windows.Forms.TextBox();
            this.textBoxCheckProfileUserIdResult = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileRomCode = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileRegion = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileCountry = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileLanguage = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileSex = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileName = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileTrainerId = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBoxCheckProfileUserId = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.labelTransInvalidFriendCode = new System.Windows.Forms.Label();
            this.labelTransInvalidProfileId = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTransFriendCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxTransUserId = new System.Windows.Forms.TextBox();
            this.textBoxTransProfileId = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label73 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridViewSchedule = new AdminTool.ExtendedDataGridView();
            this.dataGridViewVipSettingRecord = new AdminTool.ExtendedDataGridView();
            this.dataGridViewSpecialWeek = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionJp = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionEn = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionFr = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionIt = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionDe = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionSp = new AdminTool.ExtendedDataGridView();
            this.dataGridViewFreeQuestionKr = new AdminTool.ExtendedDataGridView();
            this.extendedDataGridView1 = new AdminTool.ExtendedDataGridView();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVipRecord)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorVipSettingRecord)).BeginInit();
            this.bindingNavigatorVipSettingRecord.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSchedule)).BeginInit();
            this.bindingNavigatorSchedule.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSpecialWeek)).BeginInit();
            this.bindingNavigatorSpecialWeek.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchedule)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVipSettingRecord)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSpecialWeek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionJp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionEn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionFr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionIt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionDe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionSp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionKr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.extendedDataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxAdminResult
            // 
            this.textBoxAdminResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAdminResult.Location = new System.Drawing.Point(6, 18);
            this.textBoxAdminResult.Name = "textBoxAdminResult";
            this.textBoxAdminResult.ReadOnly = true;
            this.textBoxAdminResult.Size = new System.Drawing.Size(879, 19);
            this.textBoxAdminResult.TabIndex = 4;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルFToolStripMenuItem,
            this.設定SToolStripMenuItem,
            this.ヘルプFToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(932, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルFToolStripMenuItem
            // 
            this.ファイルFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemExit});
            this.ファイルFToolStripMenuItem.Name = "ファイルFToolStripMenuItem";
            this.ファイルFToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.ファイルFToolStripMenuItem.Text = "ファイル(&F)";
            // 
            // ToolStripMenuItemExit
            // 
            this.ToolStripMenuItemExit.Name = "ToolStripMenuItemExit";
            this.ToolStripMenuItemExit.Size = new System.Drawing.Size(188, 22);
            this.ToolStripMenuItemExit.Text = "アプリケーションの終了(&X)";
            this.ToolStripMenuItemExit.Click += new System.EventHandler(this.ToolStripMenuItemExit_Click);
            // 
            // 設定SToolStripMenuItem
            // 
            this.設定SToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.接続サーバToolStripMenuItem,
            this.ToolStripMenuItemProxySetting});
            this.設定SToolStripMenuItem.Name = "設定SToolStripMenuItem";
            this.設定SToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.設定SToolStripMenuItem.Text = "設定(&S)";
            // 
            // 接続サーバToolStripMenuItem
            // 
            this.接続サーバToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemDebugServer,
            this.ToolStripMenuItemReleaseServer,
            this.toolStripSeparator1,
            this.ToolStripMenuItemDevDebugServer,
            this.ToolStripMenuItemDevReleaseServer});
            this.接続サーバToolStripMenuItem.Name = "接続サーバToolStripMenuItem";
            this.接続サーバToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.接続サーバToolStripMenuItem.Text = "接続サーバ(&S)";
            // 
            // ToolStripMenuItemDebugServer
            // 
            this.ToolStripMenuItemDebugServer.Checked = true;
            this.ToolStripMenuItemDebugServer.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ToolStripMenuItemDebugServer.Name = "ToolStripMenuItemDebugServer";
            this.ToolStripMenuItemDebugServer.Size = new System.Drawing.Size(172, 22);
            this.ToolStripMenuItemDebugServer.Text = "デバッグサーバ";
            this.ToolStripMenuItemDebugServer.Click += new System.EventHandler(this.ToolStripMenuItemDebugServer_Click);
            // 
            // ToolStripMenuItemReleaseServer
            // 
            this.ToolStripMenuItemReleaseServer.Name = "ToolStripMenuItemReleaseServer";
            this.ToolStripMenuItemReleaseServer.Size = new System.Drawing.Size(172, 22);
            this.ToolStripMenuItemReleaseServer.Text = "リリースサーバ";
            this.ToolStripMenuItemReleaseServer.Click += new System.EventHandler(this.ToolStripMenuItemReleaseServer_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(169, 6);
            // 
            // ToolStripMenuItemDevDebugServer
            // 
            this.ToolStripMenuItemDevDebugServer.Name = "ToolStripMenuItemDevDebugServer";
            this.ToolStripMenuItemDevDebugServer.Size = new System.Drawing.Size(172, 22);
            this.ToolStripMenuItemDevDebugServer.Text = "開発用デバッグサーバ";
            this.ToolStripMenuItemDevDebugServer.Click += new System.EventHandler(this.ToolStripMenuItemDevDebugServer_Click);
            // 
            // ToolStripMenuItemDevReleaseServer
            // 
            this.ToolStripMenuItemDevReleaseServer.Name = "ToolStripMenuItemDevReleaseServer";
            this.ToolStripMenuItemDevReleaseServer.Size = new System.Drawing.Size(172, 22);
            this.ToolStripMenuItemDevReleaseServer.Text = "開発用リリースサーバ";
            this.ToolStripMenuItemDevReleaseServer.Click += new System.EventHandler(this.ToolStripMenuItemDevReleaseServer_Click);
            // 
            // ToolStripMenuItemProxySetting
            // 
            this.ToolStripMenuItemProxySetting.Name = "ToolStripMenuItemProxySetting";
            this.ToolStripMenuItemProxySetting.Size = new System.Drawing.Size(153, 22);
            this.ToolStripMenuItemProxySetting.Text = "プロキシ設定...(&P)";
            this.ToolStripMenuItemProxySetting.Click += new System.EventHandler(this.ToolStripMenuItemProxySetting_Click);
            // 
            // ヘルプFToolStripMenuItem
            // 
            this.ヘルプFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemVersion});
            this.ヘルプFToolStripMenuItem.Name = "ヘルプFToolStripMenuItem";
            this.ヘルプFToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.ヘルプFToolStripMenuItem.Text = "ヘルプ(&H)";
            // 
            // ToolStripMenuItemVersion
            // 
            this.ToolStripMenuItemVersion.Name = "ToolStripMenuItemVersion";
            this.ToolStripMenuItemVersion.Size = new System.Drawing.Size(155, 22);
            this.ToolStripMenuItemVersion.Text = "バージョン情報(&A)";
            this.ToolStripMenuItemVersion.Click += new System.EventHandler(this.ToolStripMenuItemVersion_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.textBoxAdminResult);
            this.groupBox2.Location = new System.Drawing.Point(12, 32);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(891, 50);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "通信結果";
            // 
            // backgroundWorkerThread
            // 
            this.backgroundWorkerThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerGetServerState_DoWork);
            this.backgroundWorkerThread.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorkerGetServerState_RunWorkerCompleted);
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(114, 17);
            this.toolStripStatusLabel.Text = "toolStripStatusLabel1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 480);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(932, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label51);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmVipPid_UserId);
            this.tabPage3.Controls.Add(this.labelVipConfirmWarning);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.textBoxVipConfirm4);
            this.tabPage3.Controls.Add(this.textBoxVipConfirm3);
            this.tabPage3.Controls.Add(this.textBoxVipConfirm2);
            this.tabPage3.Controls.Add(this.textBoxVipConfirm1);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmD);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmC);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmB);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmA);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordSP);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordDE);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordIT);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordFR);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordEN);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordKR);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmPasswordJP);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmKey);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmEventId);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmVipPid);
            this.tabPage3.Controls.Add(this.textBoxVipConfirmClientTrainerId);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(900, 364);
            this.tabPage3.TabIndex = 10;
            this.tabPage3.Text = "VIP確認";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(415, 34);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(46, 12);
            this.label51.TabIndex = 46;
            this.label51.Text = "ユーザID";
            // 
            // textBoxVipConfirmVipPid_UserId
            // 
            this.textBoxVipConfirmVipPid_UserId.Location = new System.Drawing.Point(467, 31);
            this.textBoxVipConfirmVipPid_UserId.Name = "textBoxVipConfirmVipPid_UserId";
            this.textBoxVipConfirmVipPid_UserId.ReadOnly = true;
            this.textBoxVipConfirmVipPid_UserId.Size = new System.Drawing.Size(45, 19);
            this.textBoxVipConfirmVipPid_UserId.TabIndex = 4;
            this.textBoxVipConfirmVipPid_UserId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelVipConfirmWarning
            // 
            this.labelVipConfirmWarning.AutoSize = true;
            this.labelVipConfirmWarning.ForeColor = System.Drawing.Color.Red;
            this.labelVipConfirmWarning.Location = new System.Drawing.Point(255, 78);
            this.labelVipConfirmWarning.Name = "labelVipConfirmWarning";
            this.labelVipConfirmWarning.Size = new System.Drawing.Size(165, 12);
            this.labelVipConfirmWarning.TabIndex = 40;
            this.labelVipConfirmWarning.Text = "情報が正しく入力されていません。";
            this.labelVipConfirmWarning.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 138);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 12);
            this.label26.TabIndex = 39;
            this.label26.Text = "単語インデックス";
            // 
            // textBoxVipConfirm4
            // 
            this.textBoxVipConfirm4.Location = new System.Drawing.Point(546, 135);
            this.textBoxVipConfirm4.Name = "textBoxVipConfirm4";
            this.textBoxVipConfirm4.ReadOnly = true;
            this.textBoxVipConfirm4.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirm4.TabIndex = 13;
            this.textBoxVipConfirm4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirm3
            // 
            this.textBoxVipConfirm3.Location = new System.Drawing.Point(422, 135);
            this.textBoxVipConfirm3.Name = "textBoxVipConfirm3";
            this.textBoxVipConfirm3.ReadOnly = true;
            this.textBoxVipConfirm3.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirm3.TabIndex = 12;
            this.textBoxVipConfirm3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirm2
            // 
            this.textBoxVipConfirm2.Location = new System.Drawing.Point(298, 135);
            this.textBoxVipConfirm2.Name = "textBoxVipConfirm2";
            this.textBoxVipConfirm2.ReadOnly = true;
            this.textBoxVipConfirm2.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirm2.TabIndex = 11;
            this.textBoxVipConfirm2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirm1
            // 
            this.textBoxVipConfirm1.Location = new System.Drawing.Point(174, 135);
            this.textBoxVipConfirm1.Name = "textBoxVipConfirm1";
            this.textBoxVipConfirm1.ReadOnly = true;
            this.textBoxVipConfirm1.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirm1.TabIndex = 10;
            this.textBoxVipConfirm1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(405, 138);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(11, 12);
            this.label22.TabIndex = 34;
            this.label22.Text = "3";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(529, 138);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(11, 12);
            this.label23.TabIndex = 33;
            this.label23.Text = "4";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(281, 138);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(11, 12);
            this.label24.TabIndex = 32;
            this.label24.Text = "2";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(157, 138);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(11, 12);
            this.label25.TabIndex = 31;
            this.label25.Text = "1";
            // 
            // textBoxVipConfirmD
            // 
            this.textBoxVipConfirmD.Location = new System.Drawing.Point(546, 110);
            this.textBoxVipConfirmD.Name = "textBoxVipConfirmD";
            this.textBoxVipConfirmD.ReadOnly = true;
            this.textBoxVipConfirmD.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirmD.TabIndex = 9;
            this.textBoxVipConfirmD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirmC
            // 
            this.textBoxVipConfirmC.Location = new System.Drawing.Point(422, 110);
            this.textBoxVipConfirmC.Name = "textBoxVipConfirmC";
            this.textBoxVipConfirmC.ReadOnly = true;
            this.textBoxVipConfirmC.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirmC.TabIndex = 8;
            this.textBoxVipConfirmC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirmB
            // 
            this.textBoxVipConfirmB.Location = new System.Drawing.Point(298, 110);
            this.textBoxVipConfirmB.Name = "textBoxVipConfirmB";
            this.textBoxVipConfirmB.ReadOnly = true;
            this.textBoxVipConfirmB.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirmB.TabIndex = 7;
            this.textBoxVipConfirmB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirmA
            // 
            this.textBoxVipConfirmA.Location = new System.Drawing.Point(174, 110);
            this.textBoxVipConfirmA.Name = "textBoxVipConfirmA";
            this.textBoxVipConfirmA.ReadOnly = true;
            this.textBoxVipConfirmA.Size = new System.Drawing.Size(87, 19);
            this.textBoxVipConfirmA.TabIndex = 6;
            this.textBoxVipConfirmA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(391, 113);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(25, 12);
            this.label21.TabIndex = 26;
            this.label21.Text = "C値";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(515, 113);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(25, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "D値";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(267, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 12);
            this.label19.TabIndex = 24;
            this.label19.Text = "B値";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(143, 113);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 12);
            this.label18.TabIndex = 23;
            this.label18.Text = "A値";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(71, 323);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 12);
            this.label17.TabIndex = 22;
            this.label17.Text = "韓国語";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(58, 298);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 12);
            this.label16.TabIndex = 21;
            this.label16.Text = "スペイン語";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(68, 273);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 12);
            this.label15.TabIndex = 20;
            this.label15.Text = "ドイツ語";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(62, 248);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 12);
            this.label14.TabIndex = 19;
            this.label14.Text = "イタリア語";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(61, 223);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 12);
            this.label13.TabIndex = 18;
            this.label13.Text = "フランス語";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(83, 198);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 17;
            this.label12.Text = "英語";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(71, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 16;
            this.label11.Text = "日本語";
            // 
            // textBoxVipConfirmPasswordSP
            // 
            this.textBoxVipConfirmPasswordSP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordSP.Location = new System.Drawing.Point(118, 295);
            this.textBoxVipConfirmPasswordSP.Name = "textBoxVipConfirmPasswordSP";
            this.textBoxVipConfirmPasswordSP.ReadOnly = true;
            this.textBoxVipConfirmPasswordSP.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordSP.TabIndex = 19;
            // 
            // textBoxVipConfirmPasswordDE
            // 
            this.textBoxVipConfirmPasswordDE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordDE.Location = new System.Drawing.Point(118, 270);
            this.textBoxVipConfirmPasswordDE.Name = "textBoxVipConfirmPasswordDE";
            this.textBoxVipConfirmPasswordDE.ReadOnly = true;
            this.textBoxVipConfirmPasswordDE.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordDE.TabIndex = 18;
            // 
            // textBoxVipConfirmPasswordIT
            // 
            this.textBoxVipConfirmPasswordIT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordIT.Location = new System.Drawing.Point(118, 245);
            this.textBoxVipConfirmPasswordIT.Name = "textBoxVipConfirmPasswordIT";
            this.textBoxVipConfirmPasswordIT.ReadOnly = true;
            this.textBoxVipConfirmPasswordIT.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordIT.TabIndex = 17;
            // 
            // textBoxVipConfirmPasswordFR
            // 
            this.textBoxVipConfirmPasswordFR.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordFR.Location = new System.Drawing.Point(118, 220);
            this.textBoxVipConfirmPasswordFR.Name = "textBoxVipConfirmPasswordFR";
            this.textBoxVipConfirmPasswordFR.ReadOnly = true;
            this.textBoxVipConfirmPasswordFR.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordFR.TabIndex = 16;
            // 
            // textBoxVipConfirmPasswordEN
            // 
            this.textBoxVipConfirmPasswordEN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordEN.Location = new System.Drawing.Point(118, 195);
            this.textBoxVipConfirmPasswordEN.Name = "textBoxVipConfirmPasswordEN";
            this.textBoxVipConfirmPasswordEN.ReadOnly = true;
            this.textBoxVipConfirmPasswordEN.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordEN.TabIndex = 15;
            // 
            // textBoxVipConfirmPasswordKR
            // 
            this.textBoxVipConfirmPasswordKR.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordKR.Location = new System.Drawing.Point(118, 320);
            this.textBoxVipConfirmPasswordKR.Name = "textBoxVipConfirmPasswordKR";
            this.textBoxVipConfirmPasswordKR.ReadOnly = true;
            this.textBoxVipConfirmPasswordKR.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordKR.TabIndex = 20;
            // 
            // textBoxVipConfirmPasswordJP
            // 
            this.textBoxVipConfirmPasswordJP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVipConfirmPasswordJP.Location = new System.Drawing.Point(118, 170);
            this.textBoxVipConfirmPasswordJP.Name = "textBoxVipConfirmPasswordJP";
            this.textBoxVipConfirmPasswordJP.ReadOnly = true;
            this.textBoxVipConfirmPasswordJP.Size = new System.Drawing.Size(776, 19);
            this.textBoxVipConfirmPasswordJP.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "合言葉";
            // 
            // textBoxVipConfirmKey
            // 
            this.textBoxVipConfirmKey.Location = new System.Drawing.Point(37, 110);
            this.textBoxVipConfirmKey.Name = "textBoxVipConfirmKey";
            this.textBoxVipConfirmKey.ReadOnly = true;
            this.textBoxVipConfirmKey.Size = new System.Drawing.Size(100, 19);
            this.textBoxVipConfirmKey.TabIndex = 5;
            this.textBoxVipConfirmKey.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVipConfirmEventId
            // 
            this.textBoxVipConfirmEventId.Location = new System.Drawing.Point(257, 56);
            this.textBoxVipConfirmEventId.MaxLength = 11;
            this.textBoxVipConfirmEventId.Name = "textBoxVipConfirmEventId";
            this.textBoxVipConfirmEventId.Size = new System.Drawing.Size(100, 19);
            this.textBoxVipConfirmEventId.TabIndex = 2;
            this.textBoxVipConfirmEventId.Text = "0";
            this.textBoxVipConfirmEventId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxVipConfirmEventId.TextChanged += new System.EventHandler(this.textBoxVipConfirmEventId_TextChanged);
            this.textBoxVipConfirmEventId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxVipConfirmEventId_KeyDown);
            // 
            // textBoxVipConfirmVipPid
            // 
            this.textBoxVipConfirmVipPid.Location = new System.Drawing.Point(257, 31);
            this.textBoxVipConfirmVipPid.MaxLength = 14;
            this.textBoxVipConfirmVipPid.Name = "textBoxVipConfirmVipPid";
            this.textBoxVipConfirmVipPid.Size = new System.Drawing.Size(100, 19);
            this.textBoxVipConfirmVipPid.TabIndex = 1;
            this.textBoxVipConfirmVipPid.Text = "0";
            this.textBoxVipConfirmVipPid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxVipConfirmVipPid.TextChanged += new System.EventHandler(this.textBoxVipConfirmVipPid_TextChanged);
            this.textBoxVipConfirmVipPid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxVipConfirmVipPid_KeyDown);
            // 
            // textBoxVipConfirmClientTrainerId
            // 
            this.textBoxVipConfirmClientTrainerId.Location = new System.Drawing.Point(257, 6);
            this.textBoxVipConfirmClientTrainerId.MaxLength = 5;
            this.textBoxVipConfirmClientTrainerId.Name = "textBoxVipConfirmClientTrainerId";
            this.textBoxVipConfirmClientTrainerId.Size = new System.Drawing.Size(100, 19);
            this.textBoxVipConfirmClientTrainerId.TabIndex = 0;
            this.textBoxVipConfirmClientTrainerId.Text = "0";
            this.textBoxVipConfirmClientTrainerId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxVipConfirmClientTrainerId.TextChanged += new System.EventHandler(this.textBoxVipConfirmClientPid_TextChanged);
            this.textBoxVipConfirmClientTrainerId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxVipConfirmClientPid_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "キー";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "イベントID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "VIP側フレンドコードまたはPIDまたはユーザID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "クライアント側トレーナーID";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.splitContainer2);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(900, 364);
            this.tabPage2.TabIndex = 9;
            this.tabPage2.Text = "VIP設定";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label1);
            this.splitContainer2.Panel1.Controls.Add(this.textBoxVipClientTrainerId);
            this.splitContainer2.Panel1.Controls.Add(this.dataGridViewVipRecord);
            this.splitContainer2.Panel1.Controls.Add(this.buttonGetVipExecute);
            this.splitContainer2.Panel1MinSize = 190;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.bindingNavigatorVipSettingRecord);
            this.splitContainer2.Panel2.Controls.Add(this.dataGridViewVipSettingRecord);
            this.splitContainer2.Size = new System.Drawing.Size(900, 364);
            this.splitContainer2.SplitterDistance = 200;
            this.splitContainer2.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "クライアント側トレーナーID";
            // 
            // textBoxVipClientTrainerId
            // 
            this.textBoxVipClientTrainerId.Location = new System.Drawing.Point(6, 50);
            this.textBoxVipClientTrainerId.Name = "textBoxVipClientTrainerId";
            this.textBoxVipClientTrainerId.Size = new System.Drawing.Size(89, 19);
            this.textBoxVipClientTrainerId.TabIndex = 2;
            this.textBoxVipClientTrainerId.Text = "0";
            this.textBoxVipClientTrainerId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dataGridViewVipRecord
            // 
            this.dataGridViewVipRecord.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewVipRecord.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVipRecord.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewVipRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVipRecord.Location = new System.Drawing.Point(3, 75);
            this.dataGridViewVipRecord.Name = "dataGridViewVipRecord";
            this.dataGridViewVipRecord.ReadOnly = true;
            this.dataGridViewVipRecord.RowTemplate.Height = 21;
            this.dataGridViewVipRecord.Size = new System.Drawing.Size(194, 286);
            this.dataGridViewVipRecord.TabIndex = 12;
            // 
            // buttonGetVipExecute
            // 
            this.buttonGetVipExecute.BackColor = System.Drawing.Color.Transparent;
            this.buttonGetVipExecute.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonGetVipExecute.Location = new System.Drawing.Point(3, 6);
            this.buttonGetVipExecute.Name = "buttonGetVipExecute";
            this.buttonGetVipExecute.Size = new System.Drawing.Size(135, 23);
            this.buttonGetVipExecute.TabIndex = 0;
            this.buttonGetVipExecute.Text = "クライアント用データ取得";
            this.buttonGetVipExecute.UseVisualStyleBackColor = false;
            this.buttonGetVipExecute.Click += new System.EventHandler(this.buttonGetVipExecute_Click);
            // 
            // bindingNavigatorVipSettingRecord
            // 
            this.bindingNavigatorVipSettingRecord.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigatorVipSettingRecord.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigatorVipSettingRecord.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigatorVipSettingRecord.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.bindingNavigatorVipSettingRecord.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.toolStripButtonCopyVipRecords,
            this.toolStripSeparator4,
            this.toolStripButtonLoadVipSetting,
            this.toolStripButtonSaveVipSetting,
            this.toolStripSeparator5,
            this.toolStripButtonAdminGetVipSettingRecordExecute,
            this.toolStripButtonAdminSetVipSettingExecute});
            this.bindingNavigatorVipSettingRecord.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorVipSettingRecord.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigatorVipSettingRecord.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigatorVipSettingRecord.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigatorVipSettingRecord.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigatorVipSettingRecord.Name = "bindingNavigatorVipSettingRecord";
            this.bindingNavigatorVipSettingRecord.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigatorVipSettingRecord.Size = new System.Drawing.Size(696, 25);
            this.bindingNavigatorVipSettingRecord.TabIndex = 11;
            this.bindingNavigatorVipSettingRecord.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "新規追加";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(27, 22);
            this.bindingNavigatorCountItem.Text = "/ {0}";
            this.bindingNavigatorCountItem.ToolTipText = "項目の総数";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "削除";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "最初に移動";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "前に戻る";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "位置";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 19);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "現在の場所";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "次に移動";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "最後に移動";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonCopyVipRecords
            // 
            this.toolStripButtonCopyVipRecords.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCopyVipRecords.Image")));
            this.toolStripButtonCopyVipRecords.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCopyVipRecords.Name = "toolStripButtonCopyVipRecords";
            this.toolStripButtonCopyVipRecords.Size = new System.Drawing.Size(49, 22);
            this.toolStripButtonCopyVipRecords.Text = "複製";
            this.toolStripButtonCopyVipRecords.Click += new System.EventHandler(this.toolStripButtonCopyVipRecords_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonLoadVipSetting
            // 
            this.toolStripButtonLoadVipSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLoadVipSetting.Image")));
            this.toolStripButtonLoadVipSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLoadVipSetting.Name = "toolStripButtonLoadVipSetting";
            this.toolStripButtonLoadVipSetting.Size = new System.Drawing.Size(82, 22);
            this.toolStripButtonLoadVipSetting.Text = "設定を開く...";
            this.toolStripButtonLoadVipSetting.Click += new System.EventHandler(this.toolStripButtonLoadVipSetting_Click);
            // 
            // toolStripButtonSaveVipSetting
            // 
            this.toolStripButtonSaveVipSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveVipSetting.Image")));
            this.toolStripButtonSaveVipSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveVipSetting.Name = "toolStripButtonSaveVipSetting";
            this.toolStripButtonSaveVipSetting.Size = new System.Drawing.Size(88, 22);
            this.toolStripButtonSaveVipSetting.Text = "設定を保存...";
            this.toolStripButtonSaveVipSetting.Click += new System.EventHandler(this.toolStripButtonSaveVipSetting_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonAdminGetVipSettingRecordExecute
            // 
            this.toolStripButtonAdminGetVipSettingRecordExecute.ForeColor = System.Drawing.Color.DarkGreen;
            this.toolStripButtonAdminGetVipSettingRecordExecute.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdminGetVipSettingRecordExecute.Image")));
            this.toolStripButtonAdminGetVipSettingRecordExecute.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdminGetVipSettingRecordExecute.Name = "toolStripButtonAdminGetVipSettingRecordExecute";
            this.toolStripButtonAdminGetVipSettingRecordExecute.Size = new System.Drawing.Size(101, 22);
            this.toolStripButtonAdminGetVipSettingRecordExecute.Text = "設定データ取得";
            this.toolStripButtonAdminGetVipSettingRecordExecute.Click += new System.EventHandler(this.toolStripButtonAdminGetVipSettingRecordExecute_Click);
            // 
            // toolStripButtonAdminSetVipSettingExecute
            // 
            this.toolStripButtonAdminSetVipSettingExecute.ForeColor = System.Drawing.Color.DarkGreen;
            this.toolStripButtonAdminSetVipSettingExecute.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdminSetVipSettingExecute.Image")));
            this.toolStripButtonAdminSetVipSettingExecute.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdminSetVipSettingExecute.Name = "toolStripButtonAdminSetVipSettingExecute";
            this.toolStripButtonAdminSetVipSettingExecute.Size = new System.Drawing.Size(102, 22);
            this.toolStripButtonAdminSetVipSettingExecute.Text = "設定データセット";
            this.toolStripButtonAdminSetVipSettingExecute.Click += new System.EventHandler(this.toolStripButtonAdminSetVipSettingExecute_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(900, 364);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "スケジュール設定";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.listViewUserSchedule);
            this.splitContainer1.Panel1.Controls.Add(this.buttonGetScheduleExecute);
            this.splitContainer1.Panel1MinSize = 148;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.bindingNavigatorSchedule);
            this.splitContainer1.Panel2.Controls.Add(this.dataGridViewSchedule);
            this.splitContainer1.Size = new System.Drawing.Size(900, 364);
            this.splitContainer1.SplitterDistance = 177;
            this.splitContainer1.TabIndex = 10;
            // 
            // listViewUserSchedule
            // 
            this.listViewUserSchedule.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewUserSchedule.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listViewUserSchedule.Location = new System.Drawing.Point(3, 35);
            this.listViewUserSchedule.Name = "listViewUserSchedule";
            this.listViewUserSchedule.Size = new System.Drawing.Size(171, 326);
            this.listViewUserSchedule.TabIndex = 9;
            this.listViewUserSchedule.UseCompatibleStateImageBehavior = false;
            this.listViewUserSchedule.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "項目";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "データ";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 81;
            // 
            // buttonGetScheduleExecute
            // 
            this.buttonGetScheduleExecute.BackColor = System.Drawing.Color.Transparent;
            this.buttonGetScheduleExecute.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonGetScheduleExecute.Location = new System.Drawing.Point(3, 6);
            this.buttonGetScheduleExecute.Name = "buttonGetScheduleExecute";
            this.buttonGetScheduleExecute.Size = new System.Drawing.Size(135, 23);
            this.buttonGetScheduleExecute.TabIndex = 0;
            this.buttonGetScheduleExecute.Text = "クライアント用データ取得";
            this.buttonGetScheduleExecute.UseVisualStyleBackColor = false;
            this.buttonGetScheduleExecute.Click += new System.EventHandler(this.buttonGetScheduleExecute_Click);
            // 
            // bindingNavigatorSchedule
            // 
            this.bindingNavigatorSchedule.AddNewItem = this.bindingNavigatorAddNewItem1;
            this.bindingNavigatorSchedule.CountItem = this.bindingNavigatorCountItem1;
            this.bindingNavigatorSchedule.DeleteItem = this.bindingNavigatorDeleteItem1;
            this.bindingNavigatorSchedule.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.bindingNavigatorSchedule.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem1,
            this.bindingNavigatorMovePreviousItem1,
            this.bindingNavigatorSeparator3,
            this.bindingNavigatorPositionItem1,
            this.bindingNavigatorCountItem1,
            this.bindingNavigatorSeparator4,
            this.bindingNavigatorMoveNextItem1,
            this.bindingNavigatorMoveLastItem1,
            this.bindingNavigatorSeparator5,
            this.bindingNavigatorAddNewItem1,
            this.bindingNavigatorDeleteItem1,
            this.toolStripButtonCopySchedule,
            this.toolStripSeparator2,
            this.toolStripButtonLoadScheduleSetting,
            this.toolStripButtonSaveScheduleSetting,
            this.toolStripSeparator3,
            this.toolStripButtonAdminGetScheduleExecute,
            this.toolStripButtonAdminSetScheduleExecute});
            this.bindingNavigatorSchedule.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorSchedule.MoveFirstItem = this.bindingNavigatorMoveFirstItem1;
            this.bindingNavigatorSchedule.MoveLastItem = this.bindingNavigatorMoveLastItem1;
            this.bindingNavigatorSchedule.MoveNextItem = this.bindingNavigatorMoveNextItem1;
            this.bindingNavigatorSchedule.MovePreviousItem = this.bindingNavigatorMovePreviousItem1;
            this.bindingNavigatorSchedule.Name = "bindingNavigatorSchedule";
            this.bindingNavigatorSchedule.PositionItem = this.bindingNavigatorPositionItem1;
            this.bindingNavigatorSchedule.Size = new System.Drawing.Size(719, 25);
            this.bindingNavigatorSchedule.TabIndex = 10;
            this.bindingNavigatorSchedule.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem1
            // 
            this.bindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem1.Image")));
            this.bindingNavigatorAddNewItem1.Name = "bindingNavigatorAddNewItem1";
            this.bindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem1.Text = "新規追加";
            // 
            // bindingNavigatorCountItem1
            // 
            this.bindingNavigatorCountItem1.Name = "bindingNavigatorCountItem1";
            this.bindingNavigatorCountItem1.Size = new System.Drawing.Size(27, 22);
            this.bindingNavigatorCountItem1.Text = "/ {0}";
            this.bindingNavigatorCountItem1.ToolTipText = "項目の総数";
            // 
            // bindingNavigatorDeleteItem1
            // 
            this.bindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem1.Image")));
            this.bindingNavigatorDeleteItem1.Name = "bindingNavigatorDeleteItem1";
            this.bindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem1.Text = "削除";
            // 
            // bindingNavigatorMoveFirstItem1
            // 
            this.bindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem1.Image")));
            this.bindingNavigatorMoveFirstItem1.Name = "bindingNavigatorMoveFirstItem1";
            this.bindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem1.Text = "最初に移動";
            // 
            // bindingNavigatorMovePreviousItem1
            // 
            this.bindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem1.Image")));
            this.bindingNavigatorMovePreviousItem1.Name = "bindingNavigatorMovePreviousItem1";
            this.bindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem1.Text = "前に戻る";
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem1
            // 
            this.bindingNavigatorPositionItem1.AccessibleName = "位置";
            this.bindingNavigatorPositionItem1.AutoSize = false;
            this.bindingNavigatorPositionItem1.Name = "bindingNavigatorPositionItem1";
            this.bindingNavigatorPositionItem1.Size = new System.Drawing.Size(50, 19);
            this.bindingNavigatorPositionItem1.Text = "0";
            this.bindingNavigatorPositionItem1.ToolTipText = "現在の場所";
            // 
            // bindingNavigatorSeparator4
            // 
            this.bindingNavigatorSeparator4.Name = "bindingNavigatorSeparator4";
            this.bindingNavigatorSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem1
            // 
            this.bindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem1.Image")));
            this.bindingNavigatorMoveNextItem1.Name = "bindingNavigatorMoveNextItem1";
            this.bindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem1.Text = "次に移動";
            // 
            // bindingNavigatorMoveLastItem1
            // 
            this.bindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem1.Image")));
            this.bindingNavigatorMoveLastItem1.Name = "bindingNavigatorMoveLastItem1";
            this.bindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem1.Text = "最後に移動";
            // 
            // bindingNavigatorSeparator5
            // 
            this.bindingNavigatorSeparator5.Name = "bindingNavigatorSeparator5";
            this.bindingNavigatorSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonCopySchedule
            // 
            this.toolStripButtonCopySchedule.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCopySchedule.Image")));
            this.toolStripButtonCopySchedule.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCopySchedule.Name = "toolStripButtonCopySchedule";
            this.toolStripButtonCopySchedule.Size = new System.Drawing.Size(49, 22);
            this.toolStripButtonCopySchedule.Text = "複製";
            this.toolStripButtonCopySchedule.Click += new System.EventHandler(this.toolStripButtonCopySchedule_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonLoadScheduleSetting
            // 
            this.toolStripButtonLoadScheduleSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLoadScheduleSetting.Image")));
            this.toolStripButtonLoadScheduleSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLoadScheduleSetting.Name = "toolStripButtonLoadScheduleSetting";
            this.toolStripButtonLoadScheduleSetting.Size = new System.Drawing.Size(82, 22);
            this.toolStripButtonLoadScheduleSetting.Text = "設定を開く...";
            this.toolStripButtonLoadScheduleSetting.Click += new System.EventHandler(this.toolStripButtonLoadScheduleSetting_Click);
            // 
            // toolStripButtonSaveScheduleSetting
            // 
            this.toolStripButtonSaveScheduleSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveScheduleSetting.Image")));
            this.toolStripButtonSaveScheduleSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveScheduleSetting.Name = "toolStripButtonSaveScheduleSetting";
            this.toolStripButtonSaveScheduleSetting.Size = new System.Drawing.Size(88, 22);
            this.toolStripButtonSaveScheduleSetting.Text = "設定を保存...";
            this.toolStripButtonSaveScheduleSetting.Click += new System.EventHandler(this.toolStripButtonSaveScheduleSetting_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonAdminGetScheduleExecute
            // 
            this.toolStripButtonAdminGetScheduleExecute.ForeColor = System.Drawing.Color.DarkGreen;
            this.toolStripButtonAdminGetScheduleExecute.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdminGetScheduleExecute.Image")));
            this.toolStripButtonAdminGetScheduleExecute.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdminGetScheduleExecute.Name = "toolStripButtonAdminGetScheduleExecute";
            this.toolStripButtonAdminGetScheduleExecute.Size = new System.Drawing.Size(101, 22);
            this.toolStripButtonAdminGetScheduleExecute.Text = "設定データ取得";
            this.toolStripButtonAdminGetScheduleExecute.Click += new System.EventHandler(this.toolStripButtonAdminGetScheduleExecute_Click);
            // 
            // toolStripButtonAdminSetScheduleExecute
            // 
            this.toolStripButtonAdminSetScheduleExecute.ForeColor = System.Drawing.Color.DarkGreen;
            this.toolStripButtonAdminSetScheduleExecute.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdminSetScheduleExecute.Image")));
            this.toolStripButtonAdminSetScheduleExecute.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdminSetScheduleExecute.Name = "toolStripButtonAdminSetScheduleExecute";
            this.toolStripButtonAdminSetScheduleExecute.Size = new System.Drawing.Size(102, 22);
            this.toolStripButtonAdminSetScheduleExecute.Text = "設定データセット";
            this.toolStripButtonAdminSetScheduleExecute.Click += new System.EventHandler(this.toolStripButtonAdminSetScheduleExecute_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage15);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Location = new System.Drawing.Point(13, 88);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(908, 389);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.splitContainer3);
            this.tabPage6.Location = new System.Drawing.Point(4, 21);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(900, 364);
            this.tabPage6.TabIndex = 13;
            this.tabPage6.Text = "アンケートスペシャルウィーク";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.textBoxQuestionnaireInfo);
            this.splitContainer3.Panel1.Controls.Add(this.label64);
            this.splitContainer3.Panel1.Controls.Add(this.textBoxGetQuestionnaireLanguage);
            this.splitContainer3.Panel1.Controls.Add(this.buttonGetQuestionnaire);
            this.splitContainer3.Panel1MinSize = 190;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.bindingNavigatorSpecialWeek);
            this.splitContainer3.Panel2.Controls.Add(this.dataGridViewSpecialWeek);
            this.splitContainer3.Size = new System.Drawing.Size(900, 364);
            this.splitContainer3.SplitterDistance = 200;
            this.splitContainer3.TabIndex = 12;
            // 
            // textBoxQuestionnaireInfo
            // 
            this.textBoxQuestionnaireInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxQuestionnaireInfo.Location = new System.Drawing.Point(8, 75);
            this.textBoxQuestionnaireInfo.Multiline = true;
            this.textBoxQuestionnaireInfo.Name = "textBoxQuestionnaireInfo";
            this.textBoxQuestionnaireInfo.Size = new System.Drawing.Size(189, 283);
            this.textBoxQuestionnaireInfo.TabIndex = 15;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(6, 35);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(56, 12);
            this.label64.TabIndex = 14;
            this.label64.Text = "言語コード";
            // 
            // textBoxGetQuestionnaireLanguage
            // 
            this.textBoxGetQuestionnaireLanguage.Location = new System.Drawing.Point(6, 50);
            this.textBoxGetQuestionnaireLanguage.Name = "textBoxGetQuestionnaireLanguage";
            this.textBoxGetQuestionnaireLanguage.Size = new System.Drawing.Size(89, 19);
            this.textBoxGetQuestionnaireLanguage.TabIndex = 2;
            this.textBoxGetQuestionnaireLanguage.Text = "1";
            this.textBoxGetQuestionnaireLanguage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // buttonGetQuestionnaire
            // 
            this.buttonGetQuestionnaire.BackColor = System.Drawing.Color.Transparent;
            this.buttonGetQuestionnaire.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonGetQuestionnaire.Location = new System.Drawing.Point(3, 6);
            this.buttonGetQuestionnaire.Name = "buttonGetQuestionnaire";
            this.buttonGetQuestionnaire.Size = new System.Drawing.Size(142, 23);
            this.buttonGetQuestionnaire.TabIndex = 0;
            this.buttonGetQuestionnaire.Text = "現在のアンケート情報取得";
            this.buttonGetQuestionnaire.UseVisualStyleBackColor = false;
            this.buttonGetQuestionnaire.Click += new System.EventHandler(this.buttonGetQuestionnaire_Click);
            // 
            // bindingNavigatorSpecialWeek
            // 
            this.bindingNavigatorSpecialWeek.AddNewItem = this.toolStripButton12;
            this.bindingNavigatorSpecialWeek.CountItem = this.toolStripLabel2;
            this.bindingNavigatorSpecialWeek.DeleteItem = this.toolStripButton13;
            this.bindingNavigatorSpecialWeek.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.bindingNavigatorSpecialWeek.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton14,
            this.toolStripButton15,
            this.toolStripSeparator11,
            this.toolStripTextBox2,
            this.toolStripLabel2,
            this.toolStripSeparator12,
            this.toolStripButton16,
            this.toolStripButton17,
            this.toolStripSeparator13,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripButtonCopySpecialWeekRecord,
            this.toolStripSeparator14,
            this.toolStripButtonLoadSpecialWeekSetting,
            this.toolStripButtonSaveSpecialWeek,
            this.toolStripSeparator15,
            this.toolStripButtonAdminGetSpecialWeekSetting,
            this.toolStripButtonAdminSetSpecialWeekSetting});
            this.bindingNavigatorSpecialWeek.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorSpecialWeek.MoveFirstItem = this.toolStripButton14;
            this.bindingNavigatorSpecialWeek.MoveLastItem = this.toolStripButton17;
            this.bindingNavigatorSpecialWeek.MoveNextItem = this.toolStripButton16;
            this.bindingNavigatorSpecialWeek.MovePreviousItem = this.toolStripButton15;
            this.bindingNavigatorSpecialWeek.Name = "bindingNavigatorSpecialWeek";
            this.bindingNavigatorSpecialWeek.PositionItem = this.toolStripTextBox2;
            this.bindingNavigatorSpecialWeek.Size = new System.Drawing.Size(696, 25);
            this.bindingNavigatorSpecialWeek.TabIndex = 11;
            this.bindingNavigatorSpecialWeek.Text = "bindingNavigator1";
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton12.Text = "新規追加";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(27, 22);
            this.toolStripLabel2.Text = "/ {0}";
            this.toolStripLabel2.ToolTipText = "項目の総数";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton13.Text = "削除";
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.RightToLeftAutoMirrorImage = true;
            this.toolStripButton14.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton14.Text = "最初に移動";
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.RightToLeftAutoMirrorImage = true;
            this.toolStripButton15.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton15.Text = "前に戻る";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "位置";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(50, 19);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "現在の場所";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.RightToLeftAutoMirrorImage = true;
            this.toolStripButton16.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton16.Text = "次に移動";
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton17.Image")));
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.RightToLeftAutoMirrorImage = true;
            this.toolStripButton17.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton17.Text = "最後に移動";
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonCopySpecialWeekRecord
            // 
            this.toolStripButtonCopySpecialWeekRecord.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCopySpecialWeekRecord.Image")));
            this.toolStripButtonCopySpecialWeekRecord.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCopySpecialWeekRecord.Name = "toolStripButtonCopySpecialWeekRecord";
            this.toolStripButtonCopySpecialWeekRecord.Size = new System.Drawing.Size(49, 22);
            this.toolStripButtonCopySpecialWeekRecord.Text = "複製";
            this.toolStripButtonCopySpecialWeekRecord.Click += new System.EventHandler(this.toolStripButtonCopySpecialWeekRecord_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonLoadSpecialWeekSetting
            // 
            this.toolStripButtonLoadSpecialWeekSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLoadSpecialWeekSetting.Image")));
            this.toolStripButtonLoadSpecialWeekSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLoadSpecialWeekSetting.Name = "toolStripButtonLoadSpecialWeekSetting";
            this.toolStripButtonLoadSpecialWeekSetting.Size = new System.Drawing.Size(82, 22);
            this.toolStripButtonLoadSpecialWeekSetting.Text = "設定を開く...";
            this.toolStripButtonLoadSpecialWeekSetting.Click += new System.EventHandler(this.toolStripButtonLoadSpecialWeekSetting_Click);
            // 
            // toolStripButtonSaveSpecialWeek
            // 
            this.toolStripButtonSaveSpecialWeek.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveSpecialWeek.Image")));
            this.toolStripButtonSaveSpecialWeek.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveSpecialWeek.Name = "toolStripButtonSaveSpecialWeek";
            this.toolStripButtonSaveSpecialWeek.Size = new System.Drawing.Size(88, 22);
            this.toolStripButtonSaveSpecialWeek.Text = "設定を保存...";
            this.toolStripButtonSaveSpecialWeek.Click += new System.EventHandler(this.toolStripButtonSaveSpecialWeek_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonAdminGetSpecialWeekSetting
            // 
            this.toolStripButtonAdminGetSpecialWeekSetting.ForeColor = System.Drawing.Color.DarkGreen;
            this.toolStripButtonAdminGetSpecialWeekSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdminGetSpecialWeekSetting.Image")));
            this.toolStripButtonAdminGetSpecialWeekSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdminGetSpecialWeekSetting.Name = "toolStripButtonAdminGetSpecialWeekSetting";
            this.toolStripButtonAdminGetSpecialWeekSetting.Size = new System.Drawing.Size(101, 22);
            this.toolStripButtonAdminGetSpecialWeekSetting.Text = "設定データ取得";
            this.toolStripButtonAdminGetSpecialWeekSetting.Click += new System.EventHandler(this.toolStripButtonAdminGetSpecialWeekSetting_Click);
            // 
            // toolStripButtonAdminSetSpecialWeekSetting
            // 
            this.toolStripButtonAdminSetSpecialWeekSetting.ForeColor = System.Drawing.Color.DarkGreen;
            this.toolStripButtonAdminSetSpecialWeekSetting.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdminSetSpecialWeekSetting.Image")));
            this.toolStripButtonAdminSetSpecialWeekSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdminSetSpecialWeekSetting.Name = "toolStripButtonAdminSetSpecialWeekSetting";
            this.toolStripButtonAdminSetSpecialWeekSetting.Size = new System.Drawing.Size(102, 22);
            this.toolStripButtonAdminSetSpecialWeekSetting.Text = "設定データセット";
            this.toolStripButtonAdminSetSpecialWeekSetting.Click += new System.EventHandler(this.toolStripButtonAdminSetSpecialWeekSetting_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.buttonSaveFreeQuestionSetting);
            this.tabPage7.Controls.Add(this.buttonLoadFreeQuestionSetting);
            this.tabPage7.Controls.Add(this.buttonGetFreeQuestion);
            this.tabPage7.Controls.Add(this.buttonSetFreeQuestion);
            this.tabPage7.Controls.Add(this.tabControl1);
            this.tabPage7.Location = new System.Drawing.Point(4, 21);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(900, 364);
            this.tabPage7.TabIndex = 14;
            this.tabPage7.Text = "アンケート任意質問";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // buttonSaveFreeQuestionSetting
            // 
            this.buttonSaveFreeQuestionSetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSaveFreeQuestionSetting.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonSaveFreeQuestionSetting.Location = new System.Drawing.Point(611, 6);
            this.buttonSaveFreeQuestionSetting.Name = "buttonSaveFreeQuestionSetting";
            this.buttonSaveFreeQuestionSetting.Size = new System.Drawing.Size(89, 25);
            this.buttonSaveFreeQuestionSetting.TabIndex = 4;
            this.buttonSaveFreeQuestionSetting.Text = "設定を保存...";
            this.buttonSaveFreeQuestionSetting.UseVisualStyleBackColor = true;
            this.buttonSaveFreeQuestionSetting.Click += new System.EventHandler(this.buttonSaveFreeQuestionSetting_Click);
            // 
            // buttonLoadFreeQuestionSetting
            // 
            this.buttonLoadFreeQuestionSetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonLoadFreeQuestionSetting.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonLoadFreeQuestionSetting.Location = new System.Drawing.Point(516, 6);
            this.buttonLoadFreeQuestionSetting.Name = "buttonLoadFreeQuestionSetting";
            this.buttonLoadFreeQuestionSetting.Size = new System.Drawing.Size(89, 25);
            this.buttonLoadFreeQuestionSetting.TabIndex = 3;
            this.buttonLoadFreeQuestionSetting.Text = "設定を開く...";
            this.buttonLoadFreeQuestionSetting.UseVisualStyleBackColor = true;
            this.buttonLoadFreeQuestionSetting.Click += new System.EventHandler(this.buttonLoadFreeQuestionSetting_Click);
            // 
            // buttonGetFreeQuestion
            // 
            this.buttonGetFreeQuestion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetFreeQuestion.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonGetFreeQuestion.Location = new System.Drawing.Point(706, 6);
            this.buttonGetFreeQuestion.Name = "buttonGetFreeQuestion";
            this.buttonGetFreeQuestion.Size = new System.Drawing.Size(89, 25);
            this.buttonGetFreeQuestion.TabIndex = 1;
            this.buttonGetFreeQuestion.Text = "取得";
            this.buttonGetFreeQuestion.UseVisualStyleBackColor = true;
            this.buttonGetFreeQuestion.Click += new System.EventHandler(this.buttonGetFreeQuestion_Click);
            // 
            // buttonSetFreeQuestion
            // 
            this.buttonSetFreeQuestion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSetFreeQuestion.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSetFreeQuestion.Location = new System.Drawing.Point(801, 6);
            this.buttonSetFreeQuestion.Name = "buttonSetFreeQuestion";
            this.buttonSetFreeQuestion.Size = new System.Drawing.Size(89, 25);
            this.buttonSetFreeQuestion.TabIndex = 2;
            this.buttonSetFreeQuestion.Text = "登録";
            this.buttonSetFreeQuestion.UseVisualStyleBackColor = true;
            this.buttonSetFreeQuestion.Click += new System.EventHandler(this.buttonSetFreeQuestion_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Location = new System.Drawing.Point(6, 37);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(888, 321);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.dataGridViewFreeQuestionJp);
            this.tabPage8.Location = new System.Drawing.Point(4, 21);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(880, 296);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "日本語";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dataGridViewFreeQuestionEn);
            this.tabPage9.Location = new System.Drawing.Point(4, 21);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(880, 296);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "英語";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.dataGridViewFreeQuestionFr);
            this.tabPage10.Location = new System.Drawing.Point(4, 21);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(880, 296);
            this.tabPage10.TabIndex = 2;
            this.tabPage10.Text = "フランス語";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.dataGridViewFreeQuestionIt);
            this.tabPage11.Location = new System.Drawing.Point(4, 21);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(880, 296);
            this.tabPage11.TabIndex = 3;
            this.tabPage11.Text = "イタリア語";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.dataGridViewFreeQuestionDe);
            this.tabPage12.Location = new System.Drawing.Point(4, 21);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(880, 296);
            this.tabPage12.TabIndex = 4;
            this.tabPage12.Text = "ドイツ語";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.dataGridViewFreeQuestionSp);
            this.tabPage13.Location = new System.Drawing.Point(4, 21);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(880, 296);
            this.tabPage13.TabIndex = 5;
            this.tabPage13.Text = "スペイン語";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.dataGridViewFreeQuestionKr);
            this.tabPage14.Location = new System.Drawing.Point(4, 21);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(880, 296);
            this.tabPage14.TabIndex = 6;
            this.tabPage14.Text = "韓国語";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.groupBox5);
            this.tabPage15.Controls.Add(this.groupBox4);
            this.tabPage15.Controls.Add(this.groupBox1);
            this.tabPage15.Location = new System.Drawing.Point(4, 21);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(900, 364);
            this.tabPage15.TabIndex = 15;
            this.tabPage15.Text = "アンケート管理";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.buttonQuestionnaireUpdate);
            this.groupBox5.Controls.Add(this.buttonInitializeQuestionnaire);
            this.groupBox5.Location = new System.Drawing.Point(6, 286);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(430, 50);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "更新と初期化";
            // 
            // buttonQuestionnaireUpdate
            // 
            this.buttonQuestionnaireUpdate.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonQuestionnaireUpdate.Location = new System.Drawing.Point(6, 18);
            this.buttonQuestionnaireUpdate.Name = "buttonQuestionnaireUpdate";
            this.buttonQuestionnaireUpdate.Size = new System.Drawing.Size(91, 23);
            this.buttonQuestionnaireUpdate.TabIndex = 15;
            this.buttonQuestionnaireUpdate.Text = "アンケート更新";
            this.buttonQuestionnaireUpdate.UseVisualStyleBackColor = true;
            this.buttonQuestionnaireUpdate.Click += new System.EventHandler(this.buttonQuestionnaireUpdate_Click);
            // 
            // buttonInitializeQuestionnaire
            // 
            this.buttonInitializeQuestionnaire.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonInitializeQuestionnaire.Location = new System.Drawing.Point(103, 18);
            this.buttonInitializeQuestionnaire.Name = "buttonInitializeQuestionnaire";
            this.buttonInitializeQuestionnaire.Size = new System.Drawing.Size(318, 23);
            this.buttonInitializeQuestionnaire.TabIndex = 16;
            this.buttonInitializeQuestionnaire.Text = "質問番号、質問通し番号、特別質問閾値を初期化して更新";
            this.buttonInitializeQuestionnaire.UseVisualStyleBackColor = true;
            this.buttonInitializeQuestionnaire.Click += new System.EventHandler(this.buttonInitializeQuestionnaire_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label80);
            this.groupBox4.Controls.Add(this.buttonSetDefaultSummerizeLanguage);
            this.groupBox4.Controls.Add(this.label79);
            this.groupBox4.Controls.Add(this.checkedListBoxDefaultSummerizeLanguage);
            this.groupBox4.Controls.Add(this.label66);
            this.groupBox4.Controls.Add(this.buttonSetSpecialQuestionThreshold);
            this.groupBox4.Controls.Add(this.textBoxSetQuestionSerialNo);
            this.groupBox4.Controls.Add(this.label78);
            this.groupBox4.Controls.Add(this.textBoxSetNextQuestionNo);
            this.groupBox4.Controls.Add(this.textBoxSetSpecialQuestionThreshold);
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.textBoxSetQuestionNo);
            this.groupBox4.Controls.Add(this.buttonSetQuestionNo);
            this.groupBox4.Controls.Add(this.label77);
            this.groupBox4.Controls.Add(this.buttonSetNextQuestionNo);
            this.groupBox4.Controls.Add(this.buttonSetQuestionSerialNo);
            this.groupBox4.Location = new System.Drawing.Point(6, 137);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(646, 143);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "パラメータ変更";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.ForeColor = System.Drawing.Color.Blue;
            this.label80.Location = new System.Drawing.Point(12, 119);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(299, 12);
            this.label80.TabIndex = 24;
            this.label80.Text = "ここで設定された値は次回のアンケート更新時に反映されます。";
            // 
            // buttonSetDefaultSummerizeLanguage
            // 
            this.buttonSetDefaultSummerizeLanguage.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSetDefaultSummerizeLanguage.Location = new System.Drawing.Point(453, 68);
            this.buttonSetDefaultSummerizeLanguage.Name = "buttonSetDefaultSummerizeLanguage";
            this.buttonSetDefaultSummerizeLanguage.Size = new System.Drawing.Size(91, 23);
            this.buttonSetDefaultSummerizeLanguage.TabIndex = 14;
            this.buttonSetDefaultSummerizeLanguage.Text = "セット";
            this.buttonSetDefaultSummerizeLanguage.UseVisualStyleBackColor = true;
            this.buttonSetDefaultSummerizeLanguage.Click += new System.EventHandler(this.buttonSetDefaultSummerizeLanguage_Click);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(422, 20);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(122, 36);
            this.label79.TabIndex = 25;
            this.label79.Text = "デフォルト集計言語\r\nスペシャルウィーク以外の\r\n集計言語を設定します。";
            // 
            // checkedListBoxDefaultSummerizeLanguage
            // 
            this.checkedListBoxDefaultSummerizeLanguage.CheckOnClick = true;
            this.checkedListBoxDefaultSummerizeLanguage.FormattingEnabled = true;
            this.checkedListBoxDefaultSummerizeLanguage.Items.AddRange(new object[] {
            "日本語",
            "英語",
            "フランス語",
            "ドイツ語",
            "イタリア語",
            "スペイン語",
            "韓国語"});
            this.checkedListBoxDefaultSummerizeLanguage.Location = new System.Drawing.Point(550, 18);
            this.checkedListBoxDefaultSummerizeLanguage.Name = "checkedListBoxDefaultSummerizeLanguage";
            this.checkedListBoxDefaultSummerizeLanguage.Size = new System.Drawing.Size(83, 102);
            this.checkedListBoxDefaultSummerizeLanguage.TabIndex = 24;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(12, 23);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(140, 12);
            this.label66.TabIndex = 10;
            this.label66.Text = "先週と今週の質問通し番号";
            // 
            // buttonSetSpecialQuestionThreshold
            // 
            this.buttonSetSpecialQuestionThreshold.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSetSpecialQuestionThreshold.Location = new System.Drawing.Point(304, 93);
            this.buttonSetSpecialQuestionThreshold.Name = "buttonSetSpecialQuestionThreshold";
            this.buttonSetSpecialQuestionThreshold.Size = new System.Drawing.Size(91, 23);
            this.buttonSetSpecialQuestionThreshold.TabIndex = 13;
            this.buttonSetSpecialQuestionThreshold.Text = "セット";
            this.buttonSetSpecialQuestionThreshold.UseVisualStyleBackColor = true;
            this.buttonSetSpecialQuestionThreshold.Click += new System.EventHandler(this.buttonSetSpecialQuestionThreshold_Click);
            // 
            // textBoxSetQuestionSerialNo
            // 
            this.textBoxSetQuestionSerialNo.Location = new System.Drawing.Point(198, 20);
            this.textBoxSetQuestionSerialNo.Name = "textBoxSetQuestionSerialNo";
            this.textBoxSetQuestionSerialNo.Size = new System.Drawing.Size(100, 19);
            this.textBoxSetQuestionSerialNo.TabIndex = 6;
            this.textBoxSetQuestionSerialNo.Text = "0";
            this.textBoxSetQuestionSerialNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(12, 98);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(77, 12);
            this.label78.TabIndex = 21;
            this.label78.Text = "特別質問閾値";
            // 
            // textBoxSetNextQuestionNo
            // 
            this.textBoxSetNextQuestionNo.Location = new System.Drawing.Point(198, 45);
            this.textBoxSetNextQuestionNo.Name = "textBoxSetNextQuestionNo";
            this.textBoxSetNextQuestionNo.Size = new System.Drawing.Size(100, 19);
            this.textBoxSetNextQuestionNo.TabIndex = 8;
            this.textBoxSetNextQuestionNo.Text = "0";
            this.textBoxSetNextQuestionNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxSetSpecialQuestionThreshold
            // 
            this.textBoxSetSpecialQuestionThreshold.Location = new System.Drawing.Point(198, 95);
            this.textBoxSetSpecialQuestionThreshold.Name = "textBoxSetSpecialQuestionThreshold";
            this.textBoxSetSpecialQuestionThreshold.Size = new System.Drawing.Size(100, 19);
            this.textBoxSetSpecialQuestionThreshold.TabIndex = 12;
            this.textBoxSetSpecialQuestionThreshold.Text = "50";
            this.textBoxSetSpecialQuestionThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(12, 48);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(87, 12);
            this.label70.TabIndex = 12;
            this.label70.Text = "今週の質問番号";
            // 
            // textBoxSetQuestionNo
            // 
            this.textBoxSetQuestionNo.Location = new System.Drawing.Point(198, 70);
            this.textBoxSetQuestionNo.Name = "textBoxSetQuestionNo";
            this.textBoxSetQuestionNo.Size = new System.Drawing.Size(100, 19);
            this.textBoxSetQuestionNo.TabIndex = 10;
            this.textBoxSetQuestionNo.Text = "-1";
            this.textBoxSetQuestionNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // buttonSetQuestionNo
            // 
            this.buttonSetQuestionNo.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSetQuestionNo.Location = new System.Drawing.Point(304, 68);
            this.buttonSetQuestionNo.Name = "buttonSetQuestionNo";
            this.buttonSetQuestionNo.Size = new System.Drawing.Size(91, 23);
            this.buttonSetQuestionNo.TabIndex = 11;
            this.buttonSetQuestionNo.Text = "セット";
            this.buttonSetQuestionNo.UseVisualStyleBackColor = true;
            this.buttonSetQuestionNo.Click += new System.EventHandler(this.buttonSetQuestionNo_Click);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(12, 73);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(119, 12);
            this.label77.TabIndex = 14;
            this.label77.Text = "先週と今週の質問番号";
            // 
            // buttonSetNextQuestionNo
            // 
            this.buttonSetNextQuestionNo.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSetNextQuestionNo.Location = new System.Drawing.Point(304, 43);
            this.buttonSetNextQuestionNo.Name = "buttonSetNextQuestionNo";
            this.buttonSetNextQuestionNo.Size = new System.Drawing.Size(91, 23);
            this.buttonSetNextQuestionNo.TabIndex = 9;
            this.buttonSetNextQuestionNo.Text = "セット";
            this.buttonSetNextQuestionNo.UseVisualStyleBackColor = true;
            this.buttonSetNextQuestionNo.Click += new System.EventHandler(this.buttonSetNextQuestionNo_Click);
            // 
            // buttonSetQuestionSerialNo
            // 
            this.buttonSetQuestionSerialNo.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSetQuestionSerialNo.Location = new System.Drawing.Point(304, 18);
            this.buttonSetQuestionSerialNo.Name = "buttonSetQuestionSerialNo";
            this.buttonSetQuestionSerialNo.Size = new System.Drawing.Size(91, 23);
            this.buttonSetQuestionSerialNo.TabIndex = 7;
            this.buttonSetQuestionSerialNo.Text = "セット";
            this.buttonSetQuestionSerialNo.UseVisualStyleBackColor = true;
            this.buttonSetQuestionSerialNo.Click += new System.EventHandler(this.buttonSetQuestionSerialNo_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label69);
            this.groupBox1.Controls.Add(this.textBoxSubmitQuestionnaireProfileId);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.textBoxSubmitQuestionnaireAnswerNo);
            this.groupBox1.Controls.Add(this.label67);
            this.groupBox1.Controls.Add(this.textBoxSubmitQuestionnaireLanguage);
            this.groupBox1.Controls.Add(this.label65);
            this.groupBox1.Controls.Add(this.textBoxSubmitQuestionnaireSerialNo);
            this.groupBox1.Controls.Add(this.buttonSubmitQuestionnaire);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(302, 125);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "アンケート提出";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(110, 24);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(49, 12);
            this.label69.TabIndex = 11;
            this.label69.Text = "ProfileID";
            // 
            // textBoxSubmitQuestionnaireProfileId
            // 
            this.textBoxSubmitQuestionnaireProfileId.Location = new System.Drawing.Point(190, 21);
            this.textBoxSubmitQuestionnaireProfileId.Name = "textBoxSubmitQuestionnaireProfileId";
            this.textBoxSubmitQuestionnaireProfileId.Size = new System.Drawing.Size(100, 19);
            this.textBoxSubmitQuestionnaireProfileId.TabIndex = 1;
            this.textBoxSubmitQuestionnaireProfileId.Text = "100000";
            this.textBoxSubmitQuestionnaireProfileId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(110, 99);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(79, 12);
            this.label68.TabIndex = 9;
            this.label68.Text = "回答番号(0-2)";
            // 
            // textBoxSubmitQuestionnaireAnswerNo
            // 
            this.textBoxSubmitQuestionnaireAnswerNo.Location = new System.Drawing.Point(190, 96);
            this.textBoxSubmitQuestionnaireAnswerNo.Name = "textBoxSubmitQuestionnaireAnswerNo";
            this.textBoxSubmitQuestionnaireAnswerNo.Size = new System.Drawing.Size(100, 19);
            this.textBoxSubmitQuestionnaireAnswerNo.TabIndex = 4;
            this.textBoxSubmitQuestionnaireAnswerNo.Text = "0";
            this.textBoxSubmitQuestionnaireAnswerNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(110, 74);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(29, 12);
            this.label67.TabIndex = 7;
            this.label67.Text = "言語";
            // 
            // textBoxSubmitQuestionnaireLanguage
            // 
            this.textBoxSubmitQuestionnaireLanguage.Location = new System.Drawing.Point(190, 71);
            this.textBoxSubmitQuestionnaireLanguage.Name = "textBoxSubmitQuestionnaireLanguage";
            this.textBoxSubmitQuestionnaireLanguage.Size = new System.Drawing.Size(100, 19);
            this.textBoxSubmitQuestionnaireLanguage.TabIndex = 3;
            this.textBoxSubmitQuestionnaireLanguage.Text = "1";
            this.textBoxSubmitQuestionnaireLanguage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(110, 49);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(74, 12);
            this.label65.TabIndex = 3;
            this.label65.Text = "質問通し番号";
            // 
            // textBoxSubmitQuestionnaireSerialNo
            // 
            this.textBoxSubmitQuestionnaireSerialNo.Location = new System.Drawing.Point(190, 46);
            this.textBoxSubmitQuestionnaireSerialNo.Name = "textBoxSubmitQuestionnaireSerialNo";
            this.textBoxSubmitQuestionnaireSerialNo.Size = new System.Drawing.Size(100, 19);
            this.textBoxSubmitQuestionnaireSerialNo.TabIndex = 2;
            this.textBoxSubmitQuestionnaireSerialNo.Text = "0";
            this.textBoxSubmitQuestionnaireSerialNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // buttonSubmitQuestionnaire
            // 
            this.buttonSubmitQuestionnaire.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonSubmitQuestionnaire.Location = new System.Drawing.Point(6, 18);
            this.buttonSubmitQuestionnaire.Name = "buttonSubmitQuestionnaire";
            this.buttonSubmitQuestionnaire.Size = new System.Drawing.Size(91, 23);
            this.buttonSubmitQuestionnaire.TabIndex = 5;
            this.buttonSubmitQuestionnaire.Text = "提出";
            this.buttonSubmitQuestionnaire.UseVisualStyleBackColor = true;
            this.buttonSubmitQuestionnaire.Click += new System.EventHandler(this.buttonSubmitQuestionnaire_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.textBoxCheckProfileTrainerTypeResult);
            this.tabPage5.Controls.Add(this.label62);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileTrainerType);
            this.tabPage5.Controls.Add(this.label61);
            this.tabPage5.Controls.Add(this.label60);
            this.tabPage5.Controls.Add(this.buttonCheckProfile);
            this.tabPage5.Controls.Add(this.label59);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileRomCodeResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileRegionResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileCountryResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileLanguageResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileSexResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileNameResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileTrainerIdResult);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileUserIdResult);
            this.tabPage5.Controls.Add(this.label58);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileRomCode);
            this.tabPage5.Controls.Add(this.label57);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileRegion);
            this.tabPage5.Controls.Add(this.label56);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileCountry);
            this.tabPage5.Controls.Add(this.label55);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileLanguage);
            this.tabPage5.Controls.Add(this.label54);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileSex);
            this.tabPage5.Controls.Add(this.label53);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileName);
            this.tabPage5.Controls.Add(this.label52);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileTrainerId);
            this.tabPage5.Controls.Add(this.label27);
            this.tabPage5.Controls.Add(this.textBoxCheckProfileUserId);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(900, 364);
            this.tabPage5.TabIndex = 12;
            this.tabPage5.Text = "不正チェック";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // textBoxCheckProfileTrainerTypeResult
            // 
            this.textBoxCheckProfileTrainerTypeResult.Location = new System.Drawing.Point(272, 188);
            this.textBoxCheckProfileTrainerTypeResult.Name = "textBoxCheckProfileTrainerTypeResult";
            this.textBoxCheckProfileTrainerTypeResult.ReadOnly = true;
            this.textBoxCheckProfileTrainerTypeResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileTrainerTypeResult.TabIndex = 22;
            this.textBoxCheckProfileTrainerTypeResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(6, 191);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(78, 12);
            this.label62.TabIndex = 29;
            this.label62.Text = "トレーナータイプ";
            // 
            // textBoxCheckProfileTrainerType
            // 
            this.textBoxCheckProfileTrainerType.Location = new System.Drawing.Point(85, 188);
            this.textBoxCheckProfileTrainerType.Name = "textBoxCheckProfileTrainerType";
            this.textBoxCheckProfileTrainerType.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileTrainerType.TabIndex = 6;
            this.textBoxCheckProfileTrainerType.Text = "1";
            this.textBoxCheckProfileTrainerType.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(340, 17);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(60, 12);
            this.label61.TabIndex = 27;
            this.label61.Text = "チェック結果";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(146, 17);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(67, 12);
            this.label60.TabIndex = 26;
            this.label60.Text = "チェックする値";
            // 
            // buttonCheckProfile
            // 
            this.buttonCheckProfile.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonCheckProfile.Location = new System.Drawing.Point(8, 6);
            this.buttonCheckProfile.Name = "buttonCheckProfile";
            this.buttonCheckProfile.Size = new System.Drawing.Size(75, 23);
            this.buttonCheckProfile.TabIndex = 9;
            this.buttonCheckProfile.Text = "不正チェック";
            this.buttonCheckProfile.UseVisualStyleBackColor = true;
            this.buttonCheckProfile.Click += new System.EventHandler(this.buttonCheckProfile_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(233, 129);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(17, 12);
            this.label59.TabIndex = 24;
            this.label59.Text = "→";
            // 
            // textBoxCheckProfileRomCodeResult
            // 
            this.textBoxCheckProfileRomCodeResult.Location = new System.Drawing.Point(272, 238);
            this.textBoxCheckProfileRomCodeResult.Name = "textBoxCheckProfileRomCodeResult";
            this.textBoxCheckProfileRomCodeResult.ReadOnly = true;
            this.textBoxCheckProfileRomCodeResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileRomCodeResult.TabIndex = 24;
            this.textBoxCheckProfileRomCodeResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCheckProfileRegionResult
            // 
            this.textBoxCheckProfileRegionResult.Location = new System.Drawing.Point(272, 213);
            this.textBoxCheckProfileRegionResult.Name = "textBoxCheckProfileRegionResult";
            this.textBoxCheckProfileRegionResult.ReadOnly = true;
            this.textBoxCheckProfileRegionResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileRegionResult.TabIndex = 23;
            this.textBoxCheckProfileRegionResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCheckProfileCountryResult
            // 
            this.textBoxCheckProfileCountryResult.Location = new System.Drawing.Point(272, 163);
            this.textBoxCheckProfileCountryResult.Name = "textBoxCheckProfileCountryResult";
            this.textBoxCheckProfileCountryResult.ReadOnly = true;
            this.textBoxCheckProfileCountryResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileCountryResult.TabIndex = 21;
            this.textBoxCheckProfileCountryResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCheckProfileLanguageResult
            // 
            this.textBoxCheckProfileLanguageResult.Location = new System.Drawing.Point(272, 138);
            this.textBoxCheckProfileLanguageResult.Name = "textBoxCheckProfileLanguageResult";
            this.textBoxCheckProfileLanguageResult.ReadOnly = true;
            this.textBoxCheckProfileLanguageResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileLanguageResult.TabIndex = 20;
            this.textBoxCheckProfileLanguageResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCheckProfileSexResult
            // 
            this.textBoxCheckProfileSexResult.Location = new System.Drawing.Point(272, 113);
            this.textBoxCheckProfileSexResult.Name = "textBoxCheckProfileSexResult";
            this.textBoxCheckProfileSexResult.ReadOnly = true;
            this.textBoxCheckProfileSexResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileSexResult.TabIndex = 19;
            this.textBoxCheckProfileSexResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCheckProfileNameResult
            // 
            this.textBoxCheckProfileNameResult.Location = new System.Drawing.Point(272, 88);
            this.textBoxCheckProfileNameResult.Name = "textBoxCheckProfileNameResult";
            this.textBoxCheckProfileNameResult.ReadOnly = true;
            this.textBoxCheckProfileNameResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileNameResult.TabIndex = 18;
            // 
            // textBoxCheckProfileTrainerIdResult
            // 
            this.textBoxCheckProfileTrainerIdResult.Location = new System.Drawing.Point(272, 63);
            this.textBoxCheckProfileTrainerIdResult.Name = "textBoxCheckProfileTrainerIdResult";
            this.textBoxCheckProfileTrainerIdResult.ReadOnly = true;
            this.textBoxCheckProfileTrainerIdResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileTrainerIdResult.TabIndex = 17;
            this.textBoxCheckProfileTrainerIdResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCheckProfileUserIdResult
            // 
            this.textBoxCheckProfileUserIdResult.Location = new System.Drawing.Point(272, 38);
            this.textBoxCheckProfileUserIdResult.Name = "textBoxCheckProfileUserIdResult";
            this.textBoxCheckProfileUserIdResult.ReadOnly = true;
            this.textBoxCheckProfileUserIdResult.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileUserIdResult.TabIndex = 16;
            this.textBoxCheckProfileUserIdResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(6, 241);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(57, 12);
            this.label58.TabIndex = 15;
            this.label58.Text = "ROMコード";
            // 
            // textBoxCheckProfileRomCode
            // 
            this.textBoxCheckProfileRomCode.Location = new System.Drawing.Point(85, 238);
            this.textBoxCheckProfileRomCode.Name = "textBoxCheckProfileRomCode";
            this.textBoxCheckProfileRomCode.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileRomCode.TabIndex = 8;
            this.textBoxCheckProfileRomCode.Text = "12";
            this.textBoxCheckProfileRomCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(6, 216);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(56, 12);
            this.label57.TabIndex = 13;
            this.label57.Text = "地域コード";
            // 
            // textBoxCheckProfileRegion
            // 
            this.textBoxCheckProfileRegion.Location = new System.Drawing.Point(85, 213);
            this.textBoxCheckProfileRegion.Name = "textBoxCheckProfileRegion";
            this.textBoxCheckProfileRegion.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileRegion.TabIndex = 7;
            this.textBoxCheckProfileRegion.Text = "1";
            this.textBoxCheckProfileRegion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(6, 166);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(44, 12);
            this.label56.TabIndex = 11;
            this.label56.Text = "国コード";
            // 
            // textBoxCheckProfileCountry
            // 
            this.textBoxCheckProfileCountry.Location = new System.Drawing.Point(85, 163);
            this.textBoxCheckProfileCountry.Name = "textBoxCheckProfileCountry";
            this.textBoxCheckProfileCountry.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileCountry.TabIndex = 5;
            this.textBoxCheckProfileCountry.Text = "103";
            this.textBoxCheckProfileCountry.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(6, 141);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(56, 12);
            this.label55.TabIndex = 9;
            this.label55.Text = "言語コード";
            // 
            // textBoxCheckProfileLanguage
            // 
            this.textBoxCheckProfileLanguage.Location = new System.Drawing.Point(85, 138);
            this.textBoxCheckProfileLanguage.Name = "textBoxCheckProfileLanguage";
            this.textBoxCheckProfileLanguage.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileLanguage.TabIndex = 4;
            this.textBoxCheckProfileLanguage.Text = "1";
            this.textBoxCheckProfileLanguage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 116);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(29, 12);
            this.label54.TabIndex = 7;
            this.label54.Text = "性別";
            // 
            // textBoxCheckProfileSex
            // 
            this.textBoxCheckProfileSex.Location = new System.Drawing.Point(85, 113);
            this.textBoxCheckProfileSex.Name = "textBoxCheckProfileSex";
            this.textBoxCheckProfileSex.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileSex.TabIndex = 3;
            this.textBoxCheckProfileSex.Text = "0";
            this.textBoxCheckProfileSex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 91);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(47, 12);
            this.label53.TabIndex = 5;
            this.label53.Text = "ユーザ名";
            // 
            // textBoxCheckProfileName
            // 
            this.textBoxCheckProfileName.Location = new System.Drawing.Point(85, 88);
            this.textBoxCheckProfileName.Name = "textBoxCheckProfileName";
            this.textBoxCheckProfileName.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileName.TabIndex = 2;
            this.textBoxCheckProfileName.Text = "プラチナ";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 66);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(63, 12);
            this.label52.TabIndex = 3;
            this.label52.Text = "トレーナーID";
            // 
            // textBoxCheckProfileTrainerId
            // 
            this.textBoxCheckProfileTrainerId.Location = new System.Drawing.Point(85, 63);
            this.textBoxCheckProfileTrainerId.Name = "textBoxCheckProfileTrainerId";
            this.textBoxCheckProfileTrainerId.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileTrainerId.TabIndex = 1;
            this.textBoxCheckProfileTrainerId.Text = "1";
            this.textBoxCheckProfileTrainerId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 41);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 12);
            this.label27.TabIndex = 1;
            this.label27.Text = "ユーザID";
            // 
            // textBoxCheckProfileUserId
            // 
            this.textBoxCheckProfileUserId.Location = new System.Drawing.Point(85, 38);
            this.textBoxCheckProfileUserId.Name = "textBoxCheckProfileUserId";
            this.textBoxCheckProfileUserId.Size = new System.Drawing.Size(128, 19);
            this.textBoxCheckProfileUserId.TabIndex = 0;
            this.textBoxCheckProfileUserId.Text = "100000";
            this.textBoxCheckProfileUserId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.labelTransInvalidFriendCode);
            this.tabPage4.Controls.Add(this.labelTransInvalidProfileId);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.textBoxTransFriendCode);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.textBoxTransUserId);
            this.tabPage4.Controls.Add(this.textBoxTransProfileId);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(900, 364);
            this.tabPage4.TabIndex = 11;
            this.tabPage4.Text = "ID変換器";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // labelTransInvalidFriendCode
            // 
            this.labelTransInvalidFriendCode.AutoSize = true;
            this.labelTransInvalidFriendCode.ForeColor = System.Drawing.Color.Red;
            this.labelTransInvalidFriendCode.Location = new System.Drawing.Point(225, 38);
            this.labelTransInvalidFriendCode.Name = "labelTransInvalidFriendCode";
            this.labelTransInvalidFriendCode.Size = new System.Drawing.Size(129, 12);
            this.labelTransInvalidFriendCode.TabIndex = 8;
            this.labelTransInvalidFriendCode.Text = "不正なフレンドコードです。";
            this.labelTransInvalidFriendCode.Visible = false;
            // 
            // labelTransInvalidProfileId
            // 
            this.labelTransInvalidProfileId.AutoSize = true;
            this.labelTransInvalidProfileId.ForeColor = System.Drawing.Color.Red;
            this.labelTransInvalidProfileId.Location = new System.Drawing.Point(225, 63);
            this.labelTransInvalidProfileId.Name = "labelTransInvalidProfileId";
            this.labelTransInvalidProfileId.Size = new System.Drawing.Size(111, 12);
            this.labelTransInvalidProfileId.TabIndex = 7;
            this.labelTransInvalidProfileId.Text = "不正なProfileIDです。";
            this.labelTransInvalidProfileId.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(566, 12);
            this.label10.TabIndex = 6;
            this.label10.Text = "フレンドコードからProfileID、ProfileIDからユーザIDを求めます。逆への変換はできません。ハイフンはなくてもかまいません。";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 12);
            this.label9.TabIndex = 5;
            this.label9.Text = "ユーザID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 12);
            this.label8.TabIndex = 4;
            this.label8.Text = "フレンドコード";
            // 
            // textBoxTransFriendCode
            // 
            this.textBoxTransFriendCode.Location = new System.Drawing.Point(79, 35);
            this.textBoxTransFriendCode.MaxLength = 14;
            this.textBoxTransFriendCode.Name = "textBoxTransFriendCode";
            this.textBoxTransFriendCode.Size = new System.Drawing.Size(140, 19);
            this.textBoxTransFriendCode.TabIndex = 1;
            this.textBoxTransFriendCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxTransFriendCode.TextChanged += new System.EventHandler(this.textBoxTransFriendCode_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "ProfileID";
            // 
            // textBoxTransUserId
            // 
            this.textBoxTransUserId.Location = new System.Drawing.Point(79, 85);
            this.textBoxTransUserId.MaxLength = 5;
            this.textBoxTransUserId.Name = "textBoxTransUserId";
            this.textBoxTransUserId.Size = new System.Drawing.Size(140, 19);
            this.textBoxTransUserId.TabIndex = 3;
            this.textBoxTransUserId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxTransProfileId
            // 
            this.textBoxTransProfileId.Location = new System.Drawing.Point(79, 60);
            this.textBoxTransProfileId.MaxLength = 10;
            this.textBoxTransProfileId.Name = "textBoxTransProfileId";
            this.textBoxTransProfileId.Size = new System.Drawing.Size(140, 19);
            this.textBoxTransProfileId.TabIndex = 2;
            this.textBoxTransProfileId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxTransProfileId.TextChanged += new System.EventHandler(this.textBoxTransProfileId_TextChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(415, 9);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(46, 12);
            this.label28.TabIndex = 44;
            this.label28.Text = "ユーザID";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(467, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(45, 19);
            this.textBox1.TabIndex = 41;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(255, 78);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(165, 12);
            this.label29.TabIndex = 40;
            this.label29.Text = "情報が正しく入力されていません。";
            this.label29.Visible = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 138);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(81, 12);
            this.label30.TabIndex = 39;
            this.label30.Text = "単語インデックス";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(546, 135);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(87, 19);
            this.textBox2.TabIndex = 38;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(422, 135);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(87, 19);
            this.textBox3.TabIndex = 37;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(298, 135);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(87, 19);
            this.textBox4.TabIndex = 36;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(174, 135);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(87, 19);
            this.textBox5.TabIndex = 35;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(405, 138);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(11, 12);
            this.label31.TabIndex = 34;
            this.label31.Text = "3";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(529, 138);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(11, 12);
            this.label32.TabIndex = 33;
            this.label32.Text = "4";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(281, 138);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(11, 12);
            this.label33.TabIndex = 32;
            this.label33.Text = "2";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(157, 138);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(11, 12);
            this.label34.TabIndex = 31;
            this.label34.Text = "1";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(546, 110);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(87, 19);
            this.textBox6.TabIndex = 30;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(422, 110);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(87, 19);
            this.textBox7.TabIndex = 29;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(298, 110);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(87, 19);
            this.textBox8.TabIndex = 28;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(174, 110);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(87, 19);
            this.textBox9.TabIndex = 27;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(391, 113);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(25, 12);
            this.label35.TabIndex = 26;
            this.label35.Text = "C値";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(515, 113);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(25, 12);
            this.label36.TabIndex = 25;
            this.label36.Text = "D値";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(267, 113);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(25, 12);
            this.label37.TabIndex = 24;
            this.label37.Text = "B値";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(143, 113);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(25, 12);
            this.label38.TabIndex = 23;
            this.label38.Text = "A値";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(71, 323);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 12);
            this.label39.TabIndex = 22;
            this.label39.Text = "韓国語";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(58, 298);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(54, 12);
            this.label40.TabIndex = 21;
            this.label40.Text = "スペイン語";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(68, 273);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(44, 12);
            this.label41.TabIndex = 20;
            this.label41.Text = "ドイツ語";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(62, 248);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(50, 12);
            this.label42.TabIndex = 19;
            this.label42.Text = "イタリア語";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(61, 223);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(51, 12);
            this.label43.TabIndex = 18;
            this.label43.Text = "フランス語";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(83, 198);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(29, 12);
            this.label44.TabIndex = 17;
            this.label44.Text = "英語";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(71, 173);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 12);
            this.label45.TabIndex = 16;
            this.label45.Text = "日本語";
            // 
            // textBox10
            // 
            this.textBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox10.Location = new System.Drawing.Point(118, 295);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(727, 19);
            this.textBox10.TabIndex = 15;
            // 
            // textBox11
            // 
            this.textBox11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox11.Location = new System.Drawing.Point(118, 270);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(727, 19);
            this.textBox11.TabIndex = 14;
            // 
            // textBox12
            // 
            this.textBox12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox12.Location = new System.Drawing.Point(118, 245);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(727, 19);
            this.textBox12.TabIndex = 13;
            // 
            // textBox13
            // 
            this.textBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox13.Location = new System.Drawing.Point(118, 220);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(727, 19);
            this.textBox13.TabIndex = 12;
            // 
            // textBox14
            // 
            this.textBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox14.Location = new System.Drawing.Point(118, 195);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(727, 19);
            this.textBox14.TabIndex = 11;
            // 
            // textBox15
            // 
            this.textBox15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox15.Location = new System.Drawing.Point(118, 320);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(727, 19);
            this.textBox15.TabIndex = 10;
            // 
            // textBox16
            // 
            this.textBox16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox16.Location = new System.Drawing.Point(118, 170);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(727, 19);
            this.textBox16.TabIndex = 9;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 173);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(41, 12);
            this.label46.TabIndex = 8;
            this.label46.Text = "合言葉";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(37, 110);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(100, 19);
            this.textBox17.TabIndex = 7;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(257, 56);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 19);
            this.textBox18.TabIndex = 2;
            this.textBox18.Text = "0";
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(257, 31);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 19);
            this.textBox19.TabIndex = 1;
            this.textBox19.Text = "100000";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(257, 6);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 19);
            this.textBox20.TabIndex = 0;
            this.textBox20.Text = "100000";
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 113);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(25, 12);
            this.label47.TabIndex = 5;
            this.label47.Text = "キー";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 59);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(52, 12);
            this.label48.TabIndex = 5;
            this.label48.Text = "イベントID";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 34);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(212, 12);
            this.label49.TabIndex = 4;
            this.label49.Text = "VIP側フレンドコードまたはPIDまたはユーザID";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 9);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(245, 12);
            this.label50.TabIndex = 3;
            this.label50.Text = "クライアント側フレンドコードまたはPIDまたはユーザID";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(6, 35);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(126, 12);
            this.label63.TabIndex = 14;
            this.label63.Text = "クライアント側トレーナーID";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(6, 50);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(89, 19);
            this.textBox21.TabIndex = 2;
            this.textBox21.Text = "0";
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 75);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 21;
            this.dataGridView1.Size = new System.Drawing.Size(194, 286);
            this.dataGridView1.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.ForeColor = System.Drawing.Color.DarkGreen;
            this.button1.Location = new System.Drawing.Point(3, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "クライアント用データ取得";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(196, 215);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 19);
            this.textBox24.TabIndex = 11;
            this.textBox24.Text = "0";
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(10, 218);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(75, 12);
            this.label71.TabIndex = 12;
            this.label71.Text = "次の質問番号";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(10, 193);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(74, 12);
            this.label72.TabIndex = 10;
            this.label72.Text = "質問通し番号";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(196, 190);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 19);
            this.textBox25.TabIndex = 9;
            this.textBox25.Text = "0";
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label73);
            this.groupBox3.Controls.Add(this.textBox26);
            this.groupBox3.Controls.Add(this.label74);
            this.groupBox3.Controls.Add(this.textBox27);
            this.groupBox3.Controls.Add(this.label75);
            this.groupBox3.Controls.Add(this.textBox28);
            this.groupBox3.Controls.Add(this.label76);
            this.groupBox3.Controls.Add(this.textBox29);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(302, 125);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "アンケート提出";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(110, 24);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(49, 12);
            this.label73.TabIndex = 11;
            this.label73.Text = "ProfileID";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(190, 21);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 19);
            this.textBox26.TabIndex = 10;
            this.textBox26.Text = "100000";
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(110, 99);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(79, 12);
            this.label74.TabIndex = 9;
            this.label74.Text = "回答番号(0-2)";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(190, 96);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 19);
            this.textBox27.TabIndex = 8;
            this.textBox27.Text = "0";
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(110, 74);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(29, 12);
            this.label75.TabIndex = 7;
            this.label75.Text = "言語";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(190, 71);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 19);
            this.textBox28.TabIndex = 6;
            this.textBox28.Text = "1";
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(110, 49);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(74, 12);
            this.label76.TabIndex = 3;
            this.label76.Text = "質問通し番号";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(190, 46);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 19);
            this.textBox29.TabIndex = 2;
            this.textBox29.Text = "0";
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.DarkGreen;
            this.button2.Location = new System.Drawing.Point(6, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "提出";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.DarkGreen;
            this.button3.Location = new System.Drawing.Point(12, 147);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 23);
            this.button3.TabIndex = 0;
            this.button3.Text = "アンケート更新";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // dataGridViewSchedule
            // 
            this.dataGridViewSchedule.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSchedule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSchedule.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSchedule.Location = new System.Drawing.Point(3, 28);
            this.dataGridViewSchedule.Name = "dataGridViewSchedule";
            this.dataGridViewSchedule.RowTemplate.Height = 21;
            this.dataGridViewSchedule.Size = new System.Drawing.Size(710, 333);
            this.dataGridViewSchedule.TabIndex = 9;
            this.dataGridViewSchedule.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewSchedule_ColumnHeaderMouseClick);
            this.dataGridViewSchedule.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataGridViewSchedule_CellPainting);
            this.dataGridViewSchedule.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewSchedule_CellFormatting);
            this.dataGridViewSchedule.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridViewSchedule_DataError);
            this.dataGridViewSchedule.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSchedule_CellContentClick);
            // 
            // dataGridViewVipSettingRecord
            // 
            this.dataGridViewVipSettingRecord.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewVipSettingRecord.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVipSettingRecord.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewVipSettingRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVipSettingRecord.Location = new System.Drawing.Point(3, 28);
            this.dataGridViewVipSettingRecord.Name = "dataGridViewVipSettingRecord";
            this.dataGridViewVipSettingRecord.RowTemplate.Height = 21;
            this.dataGridViewVipSettingRecord.Size = new System.Drawing.Size(687, 333);
            this.dataGridViewVipSettingRecord.TabIndex = 8;
            this.dataGridViewVipSettingRecord.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewVipSettingRecord_ColumnHeaderMouseClick);
            this.dataGridViewVipSettingRecord.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewVipSettingRecord_CellFormatting);
            this.dataGridViewVipSettingRecord.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridViewVipSettingRecord_DataError);
            // 
            // dataGridViewSpecialWeek
            // 
            this.dataGridViewSpecialWeek.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSpecialWeek.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSpecialWeek.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewSpecialWeek.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSpecialWeek.Location = new System.Drawing.Point(3, 28);
            this.dataGridViewSpecialWeek.Name = "dataGridViewSpecialWeek";
            this.dataGridViewSpecialWeek.RowTemplate.Height = 21;
            this.dataGridViewSpecialWeek.Size = new System.Drawing.Size(687, 333);
            this.dataGridViewSpecialWeek.TabIndex = 8;
            this.dataGridViewSpecialWeek.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewSpecialWeek_CellFormatting);
            this.dataGridViewSpecialWeek.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridViewSpecialWeek_DataError);
            // 
            // dataGridViewFreeQuestionJp
            // 
            this.dataGridViewFreeQuestionJp.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionJp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionJp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionJp.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionJp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionJp.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionJp.Name = "dataGridViewFreeQuestionJp";
            this.dataGridViewFreeQuestionJp.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionJp.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionJp.TabIndex = 10;
            // 
            // dataGridViewFreeQuestionEn
            // 
            this.dataGridViewFreeQuestionEn.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionEn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionEn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionEn.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionEn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionEn.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionEn.Name = "dataGridViewFreeQuestionEn";
            this.dataGridViewFreeQuestionEn.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionEn.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionEn.TabIndex = 11;
            // 
            // dataGridViewFreeQuestionFr
            // 
            this.dataGridViewFreeQuestionFr.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionFr.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionFr.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionFr.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionFr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionFr.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionFr.Name = "dataGridViewFreeQuestionFr";
            this.dataGridViewFreeQuestionFr.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionFr.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionFr.TabIndex = 11;
            // 
            // dataGridViewFreeQuestionIt
            // 
            this.dataGridViewFreeQuestionIt.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionIt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionIt.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionIt.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionIt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionIt.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionIt.Name = "dataGridViewFreeQuestionIt";
            this.dataGridViewFreeQuestionIt.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionIt.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionIt.TabIndex = 11;
            // 
            // dataGridViewFreeQuestionDe
            // 
            this.dataGridViewFreeQuestionDe.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionDe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionDe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionDe.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionDe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionDe.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionDe.Name = "dataGridViewFreeQuestionDe";
            this.dataGridViewFreeQuestionDe.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionDe.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionDe.TabIndex = 11;
            // 
            // dataGridViewFreeQuestionSp
            // 
            this.dataGridViewFreeQuestionSp.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionSp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionSp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionSp.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionSp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionSp.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionSp.Name = "dataGridViewFreeQuestionSp";
            this.dataGridViewFreeQuestionSp.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionSp.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionSp.TabIndex = 11;
            // 
            // dataGridViewFreeQuestionKr
            // 
            this.dataGridViewFreeQuestionKr.AllowUserToAddRows = false;
            this.dataGridViewFreeQuestionKr.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewFreeQuestionKr.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewFreeQuestionKr.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridViewFreeQuestionKr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFreeQuestionKr.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewFreeQuestionKr.Name = "dataGridViewFreeQuestionKr";
            this.dataGridViewFreeQuestionKr.RowTemplate.Height = 21;
            this.dataGridViewFreeQuestionKr.Size = new System.Drawing.Size(868, 284);
            this.dataGridViewFreeQuestionKr.TabIndex = 11;
            // 
            // extendedDataGridView1
            // 
            this.extendedDataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.extendedDataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.extendedDataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.extendedDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.extendedDataGridView1.Location = new System.Drawing.Point(3, 28);
            this.extendedDataGridView1.Name = "extendedDataGridView1";
            this.extendedDataGridView1.RowTemplate.Height = 21;
            this.extendedDataGridView1.Size = new System.Drawing.Size(687, 333);
            this.extendedDataGridView1.TabIndex = 8;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 502);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(400, 300);
            this.Name = "MainForm";
            this.Text = "AdminTool";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVipRecord)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorVipSettingRecord)).EndInit();
            this.bindingNavigatorVipSettingRecord.ResumeLayout(false);
            this.bindingNavigatorVipSettingRecord.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSchedule)).EndInit();
            this.bindingNavigatorSchedule.ResumeLayout(false);
            this.bindingNavigatorSchedule.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSpecialWeek)).EndInit();
            this.bindingNavigatorSpecialWeek.ResumeLayout(false);
            this.bindingNavigatorSpecialWeek.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchedule)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVipSettingRecord)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSpecialWeek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionJp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionEn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionFr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionIt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionDe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionSp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFreeQuestionKr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.extendedDataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemExit;
        private System.Windows.Forms.ToolStripMenuItem ヘルプFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemVersion;
        private System.Windows.Forms.TextBox textBoxAdminResult;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorkerThread;
        private System.Windows.Forms.ToolStripMenuItem 設定SToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 接続サーバToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDebugServer;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemReleaseServer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDevDebugServer;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDevReleaseServer;
        private System.Windows.Forms.OpenFileDialog openFileDialogSettingXML;
        private System.Windows.Forms.SaveFileDialog saveFileDialogSettingXML;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordJP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxVipConfirmKey;
        private System.Windows.Forms.TextBox textBoxVipConfirmEventId;
        private System.Windows.Forms.TextBox textBoxVipConfirmVipPid;
        private System.Windows.Forms.TextBox textBoxVipConfirmClientTrainerId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxVipClientTrainerId;
        private System.Windows.Forms.DataGridView dataGridViewVipRecord;
        private System.Windows.Forms.Button buttonGetVipExecute;
        private System.Windows.Forms.BindingNavigator bindingNavigatorVipSettingRecord;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private ExtendedDataGridView dataGridViewVipSettingRecord;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView listViewUserSchedule;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button buttonGetScheduleExecute;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxTransFriendCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxTransUserId;
        private System.Windows.Forms.TextBox textBoxTransProfileId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelTransInvalidProfileId;
        private System.Windows.Forms.Label labelTransInvalidFriendCode;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordSP;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordDE;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordIT;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordFR;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordEN;
        private System.Windows.Forms.TextBox textBoxVipConfirmPasswordKR;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBoxVipConfirm4;
        private System.Windows.Forms.TextBox textBoxVipConfirm3;
        private System.Windows.Forms.TextBox textBoxVipConfirm2;
        private System.Windows.Forms.TextBox textBoxVipConfirm1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBoxVipConfirmD;
        private System.Windows.Forms.TextBox textBoxVipConfirmC;
        private System.Windows.Forms.TextBox textBoxVipConfirmB;
        private System.Windows.Forms.TextBox textBoxVipConfirmA;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labelVipConfirmWarning;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBoxVipConfirmVipPid_UserId;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemProxySetting;
        private ExtendedDataGridView dataGridViewSchedule;
        private System.Windows.Forms.ToolStripButton toolStripButtonCopyVipRecords;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButtonLoadVipSetting;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveVipSetting;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdminGetVipSettingRecordExecute;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdminSetVipSettingExecute;
        private System.Windows.Forms.BindingNavigator bindingNavigatorSchedule;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButtonCopySchedule;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButtonLoadScheduleSetting;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveScheduleSetting;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdminGetScheduleExecute;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdminSetScheduleExecute;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBoxCheckProfileUserId;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBoxCheckProfileTrainerId;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBoxCheckProfileName;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBoxCheckProfileSex;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBoxCheckProfileRomCode;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxCheckProfileRegion;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBoxCheckProfileCountry;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBoxCheckProfileLanguage;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBoxCheckProfileRomCodeResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileRegionResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileCountryResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileLanguageResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileSexResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileNameResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileTrainerIdResult;
        private System.Windows.Forms.TextBox textBoxCheckProfileUserIdResult;
        private System.Windows.Forms.Button buttonCheckProfile;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBoxCheckProfileTrainerTypeResult;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBoxCheckProfileTrainerType;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox textBoxGetQuestionnaireLanguage;
        private System.Windows.Forms.Button buttonGetQuestionnaire;
        private System.Windows.Forms.BindingNavigator bindingNavigatorSpecialWeek;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripButton toolStripButtonCopySpecialWeekRecord;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripButton toolStripButtonLoadSpecialWeekSetting;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveSpecialWeek;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdminGetSpecialWeekSetting;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdminSetSpecialWeekSetting;
        private ExtendedDataGridView dataGridViewSpecialWeek;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private ExtendedDataGridView extendedDataGridView1;
        private System.Windows.Forms.TextBox textBoxQuestionnaireInfo;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private ExtendedDataGridView dataGridViewFreeQuestionJp;
        private System.Windows.Forms.Button buttonSetFreeQuestion;
        private ExtendedDataGridView dataGridViewFreeQuestionEn;
        private ExtendedDataGridView dataGridViewFreeQuestionFr;
        private ExtendedDataGridView dataGridViewFreeQuestionIt;
        private ExtendedDataGridView dataGridViewFreeQuestionDe;
        private ExtendedDataGridView dataGridViewFreeQuestionSp;
        private ExtendedDataGridView dataGridViewFreeQuestionKr;
        private System.Windows.Forms.Button buttonGetFreeQuestion;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button buttonQuestionnaireUpdate;
        private System.Windows.Forms.Button buttonSubmitQuestionnaire;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBoxSubmitQuestionnaireProfileId;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBoxSubmitQuestionnaireAnswerNo;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBoxSubmitQuestionnaireLanguage;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBoxSubmitQuestionnaireSerialNo;
        private System.Windows.Forms.Button buttonSaveFreeQuestionSetting;
        private System.Windows.Forms.Button buttonLoadFreeQuestionSetting;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBoxSetQuestionNo;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBoxSetNextQuestionNo;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBoxSetQuestionSerialNo;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button buttonSetQuestionNo;
        private System.Windows.Forms.Button buttonSetNextQuestionNo;
        private System.Windows.Forms.Button buttonSetQuestionSerialNo;
        private System.Windows.Forms.Button buttonInitializeQuestionnaire;
        private System.Windows.Forms.Button buttonSetSpecialQuestionThreshold;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBoxSetSpecialQuestionThreshold;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckedListBox checkedListBoxDefaultSummerizeLanguage;
        private System.Windows.Forms.Button buttonSetDefaultSummerizeLanguage;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.GroupBox groupBox5;
    }
}


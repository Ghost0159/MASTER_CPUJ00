/*---------------------------------------------------------------------------*
  Project:  NitroWiFi - Top - include
  File:     ninet.h

  Copyright 2005 Nintendo.  All rights reserved.

  These coded instructions, statements, and computer programs contain
  proprietary information of Nintendo of America Inc. and/or Nintendo
  Company Ltd., and are protected by Federal copyright law.  They may
  not be disclosed to third parties or copied or duplicated in any form,
  in whole or in part, without the prior written consent of Nintendo.

  $Log: ninet.h,v $
  Revision 1.1  2005/07/15 13:36:16  yasu
  NitroInet �Ƃ̌݊������l�������t�@�C��

  $NoKeywords: $
 *---------------------------------------------------------------------------*/
#include <nitroWiFi.h>

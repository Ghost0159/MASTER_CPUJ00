/*---------------------------------------------------------------------------*
  Project:  NitroWiFi - include - soc
  File:     ip.h

  Copyright 2005,2006 Nintendo. All rights reserved.

  These coded instructions, statements, and computer programs contain
  proprietary information of Nintendo of America Inc. and/or Nintendo
  Company Ltd., and are protected by Federal copyright law. They may
  not be disclosed to third parties or copied or duplicated in any form,
  in whole or in part, without the prior written consent of Nintendo.

  $Log: ip.h,v $
  Revision 1.2  2006/03/10 09:20:22  kitase_hirotake
  INDENT SOURCE

  Revision 1.1  2005/07/27 11:59:29  yasu
  �_�~�[�t�@�C��

  $NoKeywords: $
 *---------------------------------------------------------------------------*/
#ifndef NITROINET_IP_H_
#define NITROINET_IP_H_

#ifdef __cplusplus

extern "C" {
#endif

#ifdef __cplusplus

}
#endif

#endif // NITROINET_IP_H_

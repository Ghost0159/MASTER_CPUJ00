========================================================================
Note of  CodeWarrior for NINTENDO DS V2.0 Service Pack 2  installer
========================================================================
                                             October, 25th 2007
                                             Freescale game tool team


    This installer is not an update installer but a full installer.
    Please uninstall the old "CodeWarrior for NINTENDO DS V2.0" product from
    your PC before you use this installer if the old "V2.0" product is in your PC.
    We recommend that you uninstall the old "CodeWarrior for NINTENDO DS V2.0
    Service Pack 1" product from your PC before you use this installer if the
    old "V2.0 Service Pack 1" product is in your PC.
    You can not overwrite install into the directory where the old product is
    installed in.

    If the old "CodeWarrior for NINTENDO DS V2.0" product is left in your PC, 
    installer will indicate the following message and will cancel the
    installation process.

      "Setup has detected the installation of the CodeWarrior for NINTENDO DS
       Version 2.0 product\non your computer. That product must be uninstalled
       first before you can install this version.
       Setup will now exit."


